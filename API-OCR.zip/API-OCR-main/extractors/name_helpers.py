# extractors/name_helpers.py
import re
from typing import Optional, Tuple

NAME_TITLE_PATTERN = re.compile(
	r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)+"
)

ALL_CAPS_NAME_PATTERN = re.compile(
	r"\b([A-ZÁÉÍÓÚÑ]{2,}(?:\s+[A-ZÁÉÍÓÚÑ]{2,})+)\b"
)

NAME_STOPWORDS = frozenset(
	{
		"CURP",
		"MEXICO",
		"MÉXICO",
		"ESTADO",
		"NOMBRE",
		"SEXO",
		"VIGENCIA",
		"CLAVE",
		"ELECTOR",
		"FOLIO",
		"DOMICILIO",
		"FECHA",
		"NACIMIENTO",
		"TUTOR",
		"TITULAR",
		"MADRE",
		"PADRE",
		"HOMBRE",
		"MUJER",
		"CALLE",
		"COLONIA",
		"CIUDAD",
		"MUNICIPIO",
		"INSTITUTO",
		"NACIONAL",
		"ELECTORAL",
		"CERTIFICADO",
		"MEDICO",
		"MÉDICO",
		"SERVICIO",
		"REGISTRO",
		"CREDENCIAL",
		"VOTER",
		"ID",
		"OCR",
		"DE",
		"LA",
		"EL",
		"LOS",
		"LAS",
		"DEL",
		"Y",
		"O",
	}
)


def context_slice(text: str, start: int, end: int, radius: int = 200) -> str:
	a = max(0, start - radius)
	b = min(len(text), end + radius)
	return text[a:b]


def pick_title_name(text: str) -> Tuple[Optional[str], float]:
	m = NAME_TITLE_PATTERN.search(text)
	if m:
		return m.group(), 0.7
	return None, 0.0


def pick_allcaps_name(text: str, confidence: float = 0.55) -> Tuple[Optional[str], float]:
	best: Optional[str] = None
	upper_text = text.upper()
	for m in ALL_CAPS_NAME_PATTERN.finditer(upper_text):
		raw = m.group(1).strip()
		tokens = raw.split()
		kept = [t for t in tokens if t not in NAME_STOPWORDS]
		if len(kept) < 2:
			continue
		candidate = " ".join(kept)
		if len(candidate.replace(" ", "")) < 4:
			continue
		best = candidate
	if best:
		return best, confidence
	return None, 0.0


def pick_name_with_fallback(text: str) -> Tuple[Optional[str], float]:
	name, conf = pick_title_name(text)
	if name:
		return name, conf
	return pick_allcaps_name(text, 0.55)


def pick_name_in_region(
	text: str,
	start: int,
	end: int,
	radius: int = 200,
) -> Tuple[Optional[str], float]:
	region = context_slice(text, start, end, radius)
	n, c = pick_title_name(region)
	if n:
		return n, c
	return pick_allcaps_name(region, 0.55)
