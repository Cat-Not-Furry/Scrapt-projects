# extractors/curp.py
import re
from typing import Any, Dict

from extractors.base import BaseExtractor
from extractors.coords_helpers import find_line_anchor, line_below_anchor, normalize_simple
from extractors.name_helpers import pick_name_in_region, pick_name_with_fallback

CURP_PATTERN = re.compile(
	r"\b([A-Z]{4}[0-9]{6}[HM][A-Z]{5}[0-9A-Z][0-9])\b",
	re.IGNORECASE,
)

ESTADOS = [
	"AGUASCALIENTES", "BAJA CALIFORNIA", "BAJA CALIFORNIA SUR",
	"CAMPECHE", "CHIAPAS", "CHIHUAHUA", "CIUDAD DE MÉXICO",
	"COAHUILA", "COLIMA", "DURANGO", "ESTADO DE MÉXICO",
	"GUANAJUATO", "GUERRERO", "HIDALGO", "JALISCO", "MÉXICO",
	"MICHOACÁN", "MORELOS", "NAYARIT", "NUEVO LEÓN",
	"OAXACA", "PUEBLA", "QUERÉTARO", "QUINTANA ROO",
	"SAN LUIS POTOSÍ", "SINALOA", "SONORA", "TABASCO",
	"TAMAULIPAS", "TLAXCALA", "VERACRUZ", "YUCATÁN", "ZACATECAS",
]

_LEGAL_NOISE = re.compile(
	r"\b(acceder|trámite|tramite|artículo|articulo|fracción|fraccion|"
	r"REGISTRO\s+NACIONAL|REGLAMENTO|LEY\s+GENERAL|instituto\s+nacional|"
	r"identificación\s+oficial)\b",
	re.I,
)


def _normalize_geo(s: str) -> str:
	return (
		s.upper()
		.replace("Í", "I")
		.replace("Á", "A")
		.replace("É", "E")
		.replace("Ó", "O")
		.replace("Ú", "U")
		.replace("Ñ", "N")
	)


def _entidad_en_region(region: str) -> str | None:
	text_upper = _normalize_geo(region)
	for estado in ESTADOS:
		estado_norm = _normalize_geo(estado)
		if estado_norm in text_upper:
			return estado
	return None


def _normalize_newlines(text: str) -> str:
	return text.replace("\r\n", "\n").replace("\r", "\n")


def _curp_constancia_zone(text: str) -> str:
	n = _normalize_newlines(text)
	upper = n.upper()
	cl_idx = upper.find("CLAVE")
	if cl_idx >= 0:
		return n[cl_idx : min(len(n), cl_idx + 4000)]
	cut = len(n)
	for marker in (
		"REGLAMENTO",
		"ARTÍCULO",
		"ARTICULO",
		"ACCESO A LA INFORMACIÓN",
		"ACCESO A LA INFORMACION",
		"INSTITUTO NACIONAL DE TRANSPARENCIA",
	):
		p = upper.find(marker)
		if p > 400:
			cut = min(cut, p)
	return n[:cut]


def _first_curp_in_zone(zone: str) -> re.Match[str] | None:
	best: re.Match[str] | None = None
	for m in CURP_PATTERN.finditer(zone):
		ctx = zone[max(0, m.start() - 80) : m.end() + 80]
		if _LEGAL_NOISE.search(ctx) and m.start() > len(zone) * 0.65:
			continue
		best = m
		break
	return best


def _nombre_tras_etiqueta(text: str) -> tuple[str | None, float]:
	n = _normalize_newlines(text)
	m = re.search(
		r"\bNombre\s*:?\s*\n+\s*(.+?)(?=\n\s*(?:Primer|Segundo|Apellido|Sexo|Entidad|"
		r"Clave|CURP|Firma|Firma\s+Electronica|Firma\s+Electrónica)|\Z)",
		n,
		re.I | re.DOTALL,
	)
	if m:
		raw = re.sub(r"\s+", " ", m.group(1).strip())
		if len(raw) > 2 and not _LEGAL_NOISE.search(raw):
			return raw, 0.84
	m2 = re.search(
		r"\bNombre\s*:?\s+(.+?)(?=\n|Primer\s+Apellido|Sexo\b|Clave\b)",
		n,
		re.I,
	)
	if m2:
		raw = m2.group(1).strip()
		if len(raw) > 2:
			return raw, 0.8
	return None, 0.0


class CURPExtractor(BaseExtractor):
	def empty_fields(self) -> Dict[str, Any]:
		return {
			"curp": self._field_null(),
			"nombre": self._field_null(),
			"entidad": self._field_null(),
		}

	def extract_with_coords(
		self,
		text: str,
		lines: list[dict[str, Any]] | None = None,
		words: list[dict[str, Any]] | None = None,
	) -> Dict[str, Any]:
		_ = words
		if not lines:
			return self.extract(text)
		clave_anchor = find_line_anchor(lines, [r"\bCLAV[EA]\b"])
		nombre_anchor = find_line_anchor(lines, [r"\bNOMBR[EA]\b"])
		ent_anchor = find_line_anchor(lines, [r"ENTIDAD\s+DE\s+REGISTRO"])
		curp = None
		curp_conf = 0.0
		nombre = None
		nombre_conf = 0.0
		entidad = None
		ent_conf = 0.0
		search_lines = lines
		if clave_anchor:
			curp_line = line_below_anchor(lines, clave_anchor, min_dy=4, max_dy=60)
			if curp_line:
				m = CURP_PATTERN.search(curp_line.get("text", ""))
				if m:
					curp = m.group(1).upper()
					curp_conf = 0.95
		if not curp:
			for ln in search_lines:
				m = CURP_PATTERN.search(ln.get("text", ""))
				if m:
					curp = m.group(1).upper()
					curp_conf = 0.9
					break
		if nombre_anchor:
			nl = line_below_anchor(lines, nombre_anchor, min_dy=8, max_dy=70)
			if nl:
				cand = nl.get("text", "").strip()
				if cand:
					nombre = cand
					nombre_conf = 0.82
		if ent_anchor:
			el = line_below_anchor(lines, ent_anchor, min_dy=0, max_dy=40)
			if el:
				up = normalize_simple(el.get("text", ""))
				for estado in ESTADOS:
					if normalize_simple(estado) in up:
						entidad = estado
						ent_conf = 0.85
						break
		if not entidad:
			for ln in search_lines:
				up = normalize_simple(ln.get("text", ""))
				for estado in ESTADOS:
					if normalize_simple(estado) in up:
						entidad = estado
						ent_conf = 0.72
						break
				if entidad:
					break
		if not nombre or not entidad or not curp:
			fallback = self.extract(text)
			if not curp:
				curp = fallback["curp"]["value"]
				curp_conf = fallback["curp"]["confidence"]
			if not nombre:
				nombre = fallback["nombre"]["value"]
				nombre_conf = fallback["nombre"]["confidence"]
			if not entidad:
				entidad = fallback["entidad"]["value"]
				ent_conf = fallback["entidad"]["confidence"]
		return {
			"curp": {"value": curp, "confidence": curp_conf},
			"nombre": {"value": nombre, "confidence": nombre_conf},
			"entidad": {"value": entidad, "confidence": ent_conf},
		}

	def extract(self, text: str) -> Dict[str, Any]:
		zone = _curp_constancia_zone(text)
		curp_match = _first_curp_in_zone(zone)
		if not curp_match:
			curp_match = CURP_PATTERN.search(_normalize_newlines(text))

		curp = curp_match.group(1).upper() if curp_match else None
		curp_conf = 0.95 if curp_match else 0.0

		nombre = None
		name_conf = 0.0
		nombre, name_conf = _nombre_tras_etiqueta(text)
		if not nombre and curp_match:
			start, end = curp_match.start(), curp_match.end()
			nombre, name_conf = pick_name_in_region(text, start, end, radius=220)
		if not nombre:
			nombre, name_conf = pick_name_with_fallback(text)

		entidad = None
		ent_conf = 0.0
		head = _normalize_newlines(text)[:3500]
		entidad = _entidad_en_region(head)
		ent_conf = 0.82 if entidad else 0.0
		if not entidad and curp_match:
			region = text[max(0, curp_match.start() - 200) : min(len(text), curp_match.end() + 200)]
			entidad = _entidad_en_region(region)
			ent_conf = 0.8 if entidad else 0.0
		if not entidad:
			text_upper = _normalize_geo(text)
			for estado in ESTADOS:
				if _normalize_geo(estado) in text_upper:
					entidad = estado
					ent_conf = 0.65
					break

		return {
			"curp": {"value": curp, "confidence": curp_conf},
			"nombre": {"value": nombre, "confidence": name_conf},
			"entidad": {"value": entidad, "confidence": ent_conf},
		}
