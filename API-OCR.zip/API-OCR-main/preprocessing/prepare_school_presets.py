"""
Presets literales modo simple escuela (/ocr/prepare) y clasificador de iluminación.

Los valores de SCHOOL_PREPARE_PRESETS son los acordados con operación; no deben
derivarse por heurística. Los umbrales en config solo eligen qué fila aplicar.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import cv2
import numpy as np

from config import (
	OCR_PREPARE_SCHOOL_MEAN_GRAY_BAD_MAX,
	OCR_PREPARE_SCHOOL_WARM_RB_DELTA,
)
from preprocessing.enhance import compute_prepare_luma_metrics

SchoolPresetId = Literal["good", "bad", "orange", "bad_orange"]

_PREP_EPS = 1e-5


def is_server_default_prepare_bundle(
	preparar_balance_blancos: bool,
	preparar_balance_intensidad: float,
	preparar_corregir_iluminacion: bool,
	preparar_iluminacion_intensidad: float,
	preparar_desaturacion_selectiva: bool,
	preparar_desaturacion_fuerza: float,
	preparar_corregir_gamma: bool,
	preparar_gamma_valor: float,
	preparar_clahe_contraste: bool,
	preparar_saturacion: float,
	preparar_nitidez: float,
	preparar_binarizar_otsu: bool,
) -> bool:
	"""True si todos los preparar_* coinciden con los defaults del servidor (multipart neutro)."""

	def near(a: float, b: float) -> bool:
		return abs(float(a) - float(b)) < _PREP_EPS

	return (
		not preparar_balance_blancos
		and near(preparar_balance_intensidad, 0.35)
		and not preparar_corregir_iluminacion
		and near(preparar_iluminacion_intensidad, 0.5)
		and not preparar_desaturacion_selectiva
		and near(preparar_desaturacion_fuerza, 0.35)
		and not preparar_corregir_gamma
		and near(preparar_gamma_valor, 0.6)
		and not preparar_clahe_contraste
		and near(preparar_saturacion, 1.0)
		and near(preparar_nitidez, 1.0)
		and not preparar_binarizar_otsu
	)


@dataclass(frozen=True)
class SchoolPreparePreset:
	"""Parámetros del stack experimental + gamma explícito (una fila por perfil)."""

	preparar_balance_blancos: bool
	preparar_balance_intensidad: float
	preparar_corregir_iluminacion: bool
	preparar_iluminacion_intensidad: float
	preparar_desaturacion_selectiva: bool
	preparar_desaturacion_fuerza: float
	preparar_corregir_gamma: bool
	preparar_gamma_valor: float
	preparar_clahe_contraste: bool
	preparar_saturacion: float
	preparar_nitidez: float
	preparar_binarizar_otsu: bool


SCHOOL_PREPARE_PRESETS: dict[SchoolPresetId, SchoolPreparePreset] = {
	"good": SchoolPreparePreset(
		preparar_balance_blancos=True,
		preparar_balance_intensidad=0.35,
		preparar_corregir_iluminacion=True,
		preparar_iluminacion_intensidad=0.5,
		preparar_desaturacion_selectiva=True,
		preparar_desaturacion_fuerza=0.35,
		preparar_corregir_gamma=True,
		preparar_gamma_valor=0.5,
		preparar_clahe_contraste=True,
		preparar_saturacion=1.0,
		preparar_nitidez=1.0,
		preparar_binarizar_otsu=False,
	),
	"bad": SchoolPreparePreset(
		preparar_balance_blancos=True,
		preparar_balance_intensidad=1.0,
		preparar_corregir_iluminacion=True,
		preparar_iluminacion_intensidad=1.0,
		preparar_desaturacion_selectiva=True,
		preparar_desaturacion_fuerza=1.0,
		preparar_corregir_gamma=True,
		preparar_gamma_valor=0.5,
		preparar_clahe_contraste=True,
		preparar_saturacion=1.0,
		preparar_nitidez=1.0,
		preparar_binarizar_otsu=False,
	),
	"orange": SchoolPreparePreset(
		preparar_balance_blancos=True,
		preparar_balance_intensidad=1.0,
		preparar_corregir_iluminacion=True,
		preparar_iluminacion_intensidad=0.82,
		preparar_desaturacion_selectiva=True,
		preparar_desaturacion_fuerza=0.8,
		preparar_corregir_gamma=True,
		preparar_gamma_valor=0.5,
		preparar_clahe_contraste=True,
		preparar_saturacion=1.0,
		preparar_nitidez=1.0,
		preparar_binarizar_otsu=False,
	),
	"bad_orange": SchoolPreparePreset(
		preparar_balance_blancos=True,
		preparar_balance_intensidad=1.0,
		preparar_corregir_iluminacion=True,
		preparar_iluminacion_intensidad=1.0,
		preparar_desaturacion_selectiva=True,
		preparar_desaturacion_fuerza=0.7,
		preparar_corregir_gamma=True,
		preparar_gamma_valor=0.5,
		preparar_clahe_contraste=True,
		preparar_saturacion=1.0,
		preparar_nitidez=1.0,
		preparar_binarizar_otsu=False,
	),
}


def _rgb_means_rgb(image: np.ndarray, max_side_for_stats: int = 512) -> tuple[float, float, float]:
	if len(image.shape) != 3 or image.shape[2] != 3:
		return 0.0, 0.0, 0.0
	img = image.astype(np.float32)
	h, w = img.shape[:2]
	side = max(h, w)
	if side > max_side_for_stats and side > 0:
		scale = max_side_for_stats / float(side)
		new_w = max(1, int(round(w * scale)))
		new_h = max(1, int(round(h * scale)))
		img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)
	mr = float(np.mean(img[:, :, 0]))
	mg = float(np.mean(img[:, :, 1]))
	mb = float(np.mean(img[:, :, 2]))
	return mr, mg, mb


def classify_school_lighting(image: np.ndarray) -> SchoolPresetId:
	"""
	Selecciona perfil escuela usando solo umbrales de config (no sustituye literales de preset).
	Orden: mala+naranja > mala > naranja > buena.
	"""
	mean_gray, _ = compute_prepare_luma_metrics(image)
	mr, _mg, mb = _rgb_means_rgb(image)
	warm = (mr - mb) >= float(OCR_PREPARE_SCHOOL_WARM_RB_DELTA)
	bad = mean_gray < float(OCR_PREPARE_SCHOOL_MEAN_GRAY_BAD_MAX)
	if bad and warm:
		return "bad_orange"
	if bad:
		return "bad"
	if warm:
		return "orange"
	return "good"
