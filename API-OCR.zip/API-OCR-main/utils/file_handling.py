# utils/file_handling.py
import io
import logging
from pathlib import Path

import cv2
import numpy as np
from fastapi import HTTPException, UploadFile
from PIL import Image, ImageOps

from config import MAX_FILE_SIZE, SUPPORTED_EXTENSIONS
from preprocessing.compression import compress_image

logger = logging.getLogger(__name__)


def validate_file(file: UploadFile):
    ext = Path(file.filename).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            400, f"Formato no soportado: {ext}. Use {SUPPORTED_EXTENSIONS}"
        )


async def read_image(
    file: UploadFile,
    compress: bool = True,
    max_size_mb: float = 0.8,
    max_dimension: int = 1000,
) -> tuple[np.ndarray, int]:
    """
    Lee un UploadFile y lo convierte en array numpy (RGB).
    Retorna (imagen_rgb, tamaño_original_en_bytes).
    Si compress=True y el archivo supera max_size_mb, puede comprimir/redimensionar.
    Nota: /ocr/prepare y /ocr/extract pasan siempre compress=False y max_dimension desde
    config (p. ej. OCR_PREPARE_READ_MAX_DIM); no usan estos valores por defecto.
    """
    contents = await file.read()
    if not contents:
        raise HTTPException(400, "El archivo está vacío o no se pudo leer.")

    original_size = len(contents)
    original_size_mb = original_size / (1024 * 1024)
    logger.info(f"Tamaño original: {original_size_mb:.2f} MB")

    # Decodificar: JPEG con EXIF de orientación (sin rotación “retrato” en servidor más allá de EXIF).
    ext = Path(file.filename or "").suffix.lower()
    if ext in (".jpg", ".jpeg"):
        try:
            pil_img = Image.open(io.BytesIO(contents))
            pil_img = ImageOps.exif_transpose(pil_img)
            if pil_img.mode != "RGB":
                pil_img = pil_img.convert("RGB")
            img_rgb = np.asarray(pil_img, dtype=np.uint8)
        except Exception as e:
            logger.warning("Fallo decodificación Pillow JPEG (%s); reintento OpenCV", e)
            nparr = np.frombuffer(contents, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                raise HTTPException(400, "No se pudo decodificar la imagen")
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    else:
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            raise HTTPException(400, "No se pudo decodificar la imagen")
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    h, w = img_rgb.shape[:2]
    if w > max_dimension or h > max_dimension:
        scale = max_dimension / max(w, h)
        new_w = int(w * scale)
        new_h = int(h * scale)
        img_rgb = cv2.resize(img_rgb, (new_w, new_h), interpolation=cv2.INTER_AREA)
        logger.info(f"Redimensionado a {new_w}x{new_h} píxeles")

    # Comprimir si se solicita y el archivo es grande
    if compress and original_size_mb > max_size_mb:
        logger.info("Aplicando compresión para reducir tamaño...")
        img_rgb = await compress_image(
            img_rgb, max_size_mb=max_size_mb, max_dimension=max_dimension
        )

        # Calcular nuevo tamaño aproximado (solo para log)
        _, buffer = cv2.imencode(".jpg", cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR))
        new_size_mb = len(buffer) / (1024 * 1024)
        logger.info(f"Tamaño después de compresión: {new_size_mb:.2f} MB")

    return img_rgb, original_size
