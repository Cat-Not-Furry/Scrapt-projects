# OCR AIDA Pro

API REST mínima con **FastAPI** para el ecosistema **AIDA**: prepara imágenes para legibilidad y extrae metadatos por trámite usando **OCR.space como único motor OCR**.

**URL de ejemplo (producción):** https://api-ocr-g2g4.onrender.com

Documentación interactiva al levantar el servicio: **`http://localhost:8000/docs`** (Swagger UI).

**Documentación producción (texto plano, UTF-8, pegado limpio en Word):** [docs/OCR_AIDA_MANUAL_OPERACION.txt](docs/OCR_AIDA_MANUAL_OPERACION.txt), [docs/OCR_AIDA_EJEMPLOS_Y_FORMATOS.txt](docs/OCR_AIDA_EJEMPLOS_Y_FORMATOS.txt).

---

## Integración mínima AIDA (plug-and-play)

Objetivo: integrar **sin** depender de todos los campos opcionales del OpenAPI.

- **POST `/ocr/prepare`:** `multipart/form-data` con un único campo obligatorio **`file`** (nombre de part estándar). El resto de campos del formulario son opcionales; con los defaults del servidor se aplica **preservación mínima** (`modo=auto`, sin binarizar, sin perspectiva ni inclinación legacy). La lectura usa **`compress=False`** y techo **`OCR_PREPARE_READ_MAX_DIM`** (no los defaults genéricos de `read_image`). CLAHE suave en prepare solo si el operador activa **`OCR_PREPARE_SOFT_CLAHE`** en el entorno (default **false**).
- **POST `/ocr/extract`:** obligatorios **`file`** y **`tramite`**. Si omites **`lang`**, el servidor usa **`spa`**. Los flags **`aplicar_saturacion_hsv`** y **`aplicar_preproceso_ocr`** pueden omitirse: entonces rigen **`OCR_APPLY_HSV_SATURATION`** y **`OCR_EXTRACT_APPLY_PREPROCESS`** (este último por defecto **desactivado**; ver tabla de variables).

**Valores válidos de `tramite`:** `acta_nacimiento`, `curp`, `ine`, `comprobante`, `certificado_medico`.

**Producción:** mantener **`PREPARE_DEFAULT_BINARIZAR=false`** en el entorno (p. ej. `render.yaml` y dashboard Render). Si el servidor tuviera **`PREPARE_DEFAULT_BINARIZAR=true`**, una petición mínima sin `binarizar=false` explícito recibiría **HTTP 400**.

**Pruebas mínimas (curl):** sustituye `BASE` por la URL del servicio (p. ej. `https://api-ocr-g2g4.onrender.com`).

```bash
BASE="https://api-ocr-g2g4.onrender.com"
curl -sS -D - -o preparada.jpg -X POST "$BASE/ocr/prepare" -F "file=@foto.jpg"
curl -sS -X POST "$BASE/ocr/extract" -F "file=@documento.jpg" -F "tramite=curp"
```

**429 y carga:** rate limit por IP en `/ocr/*` y semáforo de concurrencia; ante **429**, usar **`Retry-After`** o espaciar reintentos. Detalle en la tabla de variables de entorno y en [docs/OCR_AIDA_MANUAL_OPERACION.txt](docs/OCR_AIDA_MANUAL_OPERACION.txt).

**Texto plano para operación y ejemplos:** [docs/OCR_AIDA_MANUAL_OPERACION.txt](docs/OCR_AIDA_MANUAL_OPERACION.txt), [docs/OCR_AIDA_EJEMPLOS_Y_FORMATOS.txt](docs/OCR_AIDA_EJEMPLOS_Y_FORMATOS.txt).

---

## Requisitos

- **Python 3.12+**
- Dependencias con versiones fijas: `pip install -r requirements.txt`
- Variable obligatoria en entorno: `OCR_SPACE_API_KEY`

---

## Ejecución local

```bash
python -m venv venv
source venv/bin/activate   # Linux / macOS
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Con **Docker** (imagen según [Dockerfile](Dockerfile)):

```bash
docker build -t ocr-aida .
docker run -p 8000:8000 -e PORT=8000 ocr-aida
```

---

## Endpoints

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/` | Estado del servicio |
| GET | `/health` | Healthcheck liviano para monitoreo/keep-alive |
| POST | `/ocr/prepare` | Entrada: imagen → salida: **archivo JPEG** mejorado |
| POST | `/ocr/extract` | Entrada: imagen + trámite → salida: **JSON** con `fields` |

**Petición mínima (defaults en servidor):** `prepare` solo **`file`**; `extract` solo **`file`** + **`tramite`**. JPEG **100**, techo de lectura **4096** px de lado mayor (balance RAM y detalle). En **`/ocr/extract`**, el HSV dentro de `preprocess_light` solo aplica si activas el preproceso (`OCR_EXTRACT_APPLY_PREPROCESS` o `aplicar_preproceso_ocr=true`; por defecto **off**). **`GET /`** no cuenta para límites de carga de `/ocr/*`.

Rutas históricas (`/ocr/documento_completo`, `/ocr/basico`, `/ocr/async`, etc.) **ya no existen** en esta versión.

---

### POST `/ocr/prepare`

- **Content-Type:** `multipart/form-data`
- **Contrato actual:** solo **preservación mínima** (sin perspectiva, sin inclinación, sin binarizar, sin `fuerza_mejora`, sin `modo=legacy`). Cualquiera de esos valores “antiguos” → **HTTP 400** con mensaje que describe el contrato.
- **Política de contrato (decisión vigente):** la integración mínima AIDA sigue siendo **preservación + HSV opcional** (multipart sin pasos agresivos extra). **No** hay ruta `/ocr/prepare_enhanced` en esta versión. Una mejora visual adicional opcional existe solo **en servidor**: si **`OCR_PREPARE_SOFT_CLAHE=true`**, tras el HSV (si aplica) se ejecuta **CLAHE suave** (`apply_clahe_prepare`); por defecto está **desactivada** para no ampliar el contrato del cliente. Además existen **filtros experimentales opcionales** (multipart, todos off por defecto) que se aplican **antes** del HSV; ver lista abajo. Evaluar en staging (RAM, tiempo, percepción).
- **Lectura de entrada:** en código, `read_image` se invoca con **`compress=False`** y **`max_dimension=effective_read_dim`** (típicamente **`OCR_PREPARE_READ_MAX_DIM`**, default **4096**). **No** se usan los valores por defecto genéricos de `read_image` en [utils/file_handling.py](utils/file_handling.py) (`max_dimension=1000`, `compress=True`). El techo lateral efectivo es **`OCR_PREPARE_READ_MAX_DIM`** salvo **`lado_max_lectura`** con *tuning* por petición (ver abajo). Salida JPEG con calidad efectiva = **`OCR_PREPARE_JPEG_QUALITY`** (default **100**) salvo **`calidad_jpeg`** en el form cuando el tuning está permitido (1–100).
- **Campos admitidos en la práctica:**
	- `file` (obligatorio).
	- `modo` — debe ser **`auto`** (valor por defecto). `legacy` u otro valor → **400**.
	- `aplicar_saturacion_hsv` (opcional) — si **omitido**, se usa el env (**`OCR_APPLY_HSV_SATURATION`**, default **true** = HSV leve); **`true`**/**`false`** en el form fuerza encendido/apagado para esa petición.
	- `auto_enhance` (opcional, default `false`) — modo opt-in de mejora fotométrica. Solo aplica si servidor permite `OCR_PREPARE_ENABLE_AUTO_ENHANCE=true`.
	- `enhance_engine` (opcional) — `opencv` o `image_enhancer`. Si no se envía, se usa `OCR_PREPARE_ENHANCE_ENGINE_DEFAULT`.
	- `calidad_jpeg` (opcional, int 1–100) — solo aplica si **`OCR_PREPARE_ALLOW_REQUEST_TUNING=true`** en el servidor; si no se envía, se usa `OCR_PREPARE_JPEG_QUALITY`. Fuera de 1–100 → **400**.
	- `lado_max_lectura` (opcional, int) — techo al decodificar (`read_image`); solo aplica si **`OCR_PREPARE_ALLOW_REQUEST_TUNING=true`**. Debe estar entre **`OCR_PREPARE_READ_MIN_DIM`** y **`OCR_PREPARE_READ_MAX_DIM_CAP`** (por defecto **256** y **4096**); fuera de rango → **400**. Si el tuning está desactivado (**default `false`** en AIDA), estos dos campos se **ignoran** (valores efectivos = env/config).
	- **Experimental (pruebas; orden interno: balance blancos → iluminación → gamma → saturación → desaturación selectiva → CLAHE → nitidez → Otsu):** `preparar_balance_blancos` (bool, default false), `preparar_balance_intensidad` (float, default **0.35**, rango **0–1**; solo con balance activo; fuera de rango → **400**), `preparar_corregir_iluminacion` (bool, default false), `preparar_iluminacion_intensidad` (float, default **0.5**, rango **0–1**; solo con iluminación activa; fuera de rango → **400**), `preparar_desaturacion_selectiva` (bool, default false), `preparar_desaturacion_fuerza` (float, default **0.35**, rango **0–1**; solo con desaturación activa; fuera de rango → **400**), `preparar_corregir_gamma` (bool, default false), `preparar_gamma_valor` (float, default **0.6**, rango **0.05–5.0**; valor pasado a `apply_gamma_rgb` cuando gamma está activo; fuera de rango → **400**), `preparar_clahe_contraste` (bool, default false), `preparar_saturacion` (float, default **1.0**, rango **0–3**), `preparar_nitidez` (float, default **1.0**, rango **0–2**; valores **> 1** activan unsharp), `preparar_binarizar_otsu` (bool, default false). No sustituyen al campo legacy `binarizar` (ese sigue **prohibido** con valor true → **400**). Pueden afectar rendimiento y legibilidad; la corrección de iluminación puede alterar sellos si la intensidad es alta; combinar con `aplicar_saturacion_hsv` puede acumular cambios de color (el experimental corre **antes** del HSV del servidor).
	- **`preparar_modo_simple_escuela`** (opcional, `bool` o **omitido**): control del **comparador escuela** cuando el multipart es el **paquete neutro** de `preparar_*` (mismos defaults del servidor). Si el campo **no se envía** o vale **`true`**, y todos los `preparar_*` son neutros, tras `read_image` se aplica el comparador y los literales en [`preprocessing/prepare_school_presets.py`](preprocessing/prepare_school_presets.py) (perfiles `good` \| `bad` \| `orange` \| `bad_orange`). Si se envía explícitamente **`false`**, el comparador **no** corre aunque el paquete sea neutro (solo preservación + HSV + resto del flujo sin presets escuela). Si algún `preparar_*` no es neutro, el comparador **no** corre (se respetan los valores del formulario). Con comparador aplicado y **`OCR_PREPARE_ENABLE_AUTO_ENHANCE=true`**, se fuerza **`image_enhancer`** aunque no vengan `auto_enhance` / `enhance_engine`. Umbrales del comparador (solo selección de fila): `OCR_PREPARE_SCHOOL_MEAN_GRAY_BAD_MAX`, `OCR_PREPARE_SCHOOL_WARM_RB_DELTA`.
	- Los campos `corregir_perspectiva`, `corregir_inclinacion`, `binarizar`, `fuerza_mejora` pueden seguir en el formulario por compatibilidad con clientes viejos, pero si indican procesamiento legacy → **400**.

- **Respuesta:** cuerpo binario `image/jpeg`.

**Cabeceras:** `X-OCR-Prepare-Mode: auto`, `X-OCR-Prepare-Preset: preservacion`, `X-OCR-Prepare-JPEG-Quality`, `X-OCR-Prepare-Read-Max-Dim`, `X-OCR-Prepare-HSV` (`on` u `off`), `X-OCR-Prepare-CLAHE` (`on` solo si se aplicó CLAHE suave en servidor; ver **`OCR_PREPARE_SOFT_CLAHE`**), `X-OCR-Prepare-Enhance` (`off|opencv|image_enhancer|fallback_original`), `X-OCR-Prepare-Enhance-Engine`, `X-OCR-Prepare-Experimental` (`off` o lista de pasos aplicados: `wb`, `illum`, `gamma`, `saturation`, `desat_sel`, `clahe`, `sharpness`, `otsu`), `X-OCR-Prepare-School-Mode` (`on` si corrió el comparador escuela, `off` si no), `X-OCR-Prepare-School-Preset` (`good` \| `bad` \| `orange` \| `bad_orange` \| `off`), `X-OCR-Prepare-School-Enhance` (`off` \| `image_enhancer` \| `skipped_no_auto_enhance_env`). Con **`OCR_PREPARE_DIAGNOSTIC_HEADERS=true`** y mejora activa: `X-OCR-Prepare-Luma-Mean`, `X-OCR-Prepare-Luma-Contrast-Stdev`, `X-OCR-Prepare-Enhance-Bucket` (`dark|medium|light|near_white`), `X-OCR-Prepare-Enhance-Preset` (p. ej. `ie_dark`, `opencv_medium`).

**Escalera de calidad (referencia):** nivel 0 = preservación + JPEG; con **multipart neutro** en `preparar_*` (p. ej. solo `file`) el servidor puede aplicar **comparador escuela** salvo `preparar_modo_simple_escuela=false`; nivel 0b = filtros experimentales manuales (opt-in); nivel 1 = HSV (env o form); CLAHE suave en prepare solo si el operador activa **`OCR_PREPARE_SOFT_CLAHE`** (no forma parte del contrato mínimo cliente). El campo legacy `binarizar` sigue rechazado; binarización opcional solo con **`preparar_binarizar_otsu`**. Guía de pruebas A/B: [docs/prepare_calibration_use_cases.txt](docs/prepare_calibration_use_cases.txt). Matriz de presets P0–P13 y curls: [prepare_payloads_debug.txt](prepare_payloads_debug.txt).

**Privacidad / fixtures:** `fixtures_private/` ignorado por git.

```bash
# Petición mínima (solo archivo): si no envías preparar_* y el servidor usa defaults neutros,
# corre el comparador escuela (cabeceras X-OCR-Prepare-School-*).
curl -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	--output preparada.jpg

curl -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "aplicar_saturacion_hsv=true" \
	--output preparada_hsv.jpg

# Mejora opcional OpenCV (opt-in)
curl -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "auto_enhance=true" \
	-F "enhance_engine=opencv" \
	--output preparada_opencv.jpg

# Mejora opcional con ImageEnhancer (si falla, fallback a original)
curl -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "auto_enhance=true" \
	-F "enhance_engine=image_enhancer" \
	--output preparada_image_enhancer.jpg

# Calibracion: calidad JPEG + techo de lectura (ver prepare_payloads_debug.txt)
curl -sS -D - -o preparada_tune.jpg -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "calidad_jpeg=100" \
	-F "lado_max_lectura=4096" \
	-F "aplicar_saturacion_hsv=true"

# Filtros experimentales (pruebas; revisar cabecera X-OCR-Prepare-Experimental)
curl -sS -D - -o preparada_exp.jpg -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "preparar_corregir_gamma=true" \
	-F "preparar_clahe_contraste=true" \
	-F "preparar_saturacion=1.05" \
	-F "preparar_nitidez=1.15" \
	-F "preparar_binarizar_otsu=false"

# Balance + iluminación + desaturación selectiva (valores típicos de prueba)
curl -sS -D - -o preparada_wb_illum_desat.jpg -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "preparar_balance_blancos=true" \
	-F "preparar_balance_intensidad=0.4" \
	-F "preparar_corregir_iluminacion=true" \
	-F "preparar_iluminacion_intensidad=0.45" \
	-F "preparar_desaturacion_selectiva=true" \
	-F "preparar_desaturacion_fuerza=0.35"

# Mismo efecto que la mínima neutra: forzar intención explícita (opcional)
curl -sS -D - -o preparada_school_explicit.jpg -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "preparar_modo_simple_escuela=true"

# Paquete neutro pero sin comparador escuela (opt-out explícito)
curl -sS -D - -o preparada_sin_escuela.jpg -X POST "https://api-ocr-g2g4.onrender.com/ocr/prepare" \
	-F "file=@foto.jpg" \
	-F "preparar_modo_simple_escuela=false"
```

---

### POST `/ocr/extract`

- **Content-Type:** `multipart/form-data`
- **Campos:**
	- `file` (obligatorio)
	- `tramite` (obligatorio): `acta_nacimiento` | `curp` | `ine` | `comprobante` | `certificado_medico`
	- `lang` (opcional): idioma OCR.space, por defecto **`spa`**
	- `aplicar_saturacion_hsv` (opcional) — si **omitido**, se usa **`OCR_APPLY_HSV_SATURATION`** (default **true**); **`true`**/**`false`** fuerza por petición.
	- `aplicar_preproceso_ocr` (opcional) — si **omitido**, se usa **`OCR_EXTRACT_APPLY_PREPROCESS`** (default **false**); **`true`**/**`false`** fuerza por petición.

**Lectura de entrada:** `read_image` con **`compress=False`** y **`max_dimension=OCR_EXTRACT_READ_MAX_DIM`** (default **4096**), igual criterio que en prepare (no se usan los defaults genéricos `compress=True` / `max_dimension=1000` de [utils/file_handling.py](utils/file_handling.py)).

**Flujo resumido:** validación → lectura (techo **`OCR_EXTRACT_READ_MAX_DIM`**) → `preprocess_light` (si aplica) → llamada única a **OCR.space con overlay** → extractor por trámite con coordenadas y fallback local a texto plano → JSON.

**Nota:** `preprocess_light` **no** aplica binarización tipo Sauvola/Otsu; entrega gris tras CLAHE, sombras y denoise.

**`certificado_medico`:** orientado a **constancia Cruz Roja para estudiante** con extracción por anclas. El contrato devuelve solo: `nombre_alumno`, `direccion`, `fecha_expedicion`.

**Códigos útiles:** `400` (request inválida), `429` (rate limit), `200` silencioso funcional cuando OCR falla (con `fields` en null y `ocr_ok=false`).

**Carga (`/ocr/prepare` y `/ocr/extract` solamente):** máximo **`OCR_MAX_CONCURRENT_REQUESTS`** peticiones en vuelo por **proceso** (default **10**); si está lleno, la petición **espera** a un hueco (cola suave). Máximo **`OCR_RATE_LIMIT_REQUESTS`** peticiones por IP en **`OCR_RATE_LIMIT_WINDOW_SECONDS`** (default **30** en **600** s); al superarlo → **429**. Con **varias réplicas** en Render, cada instancia lleva su propia memoria: los límites se **multiplican** por réplicas salvo store compartido (no incluido). Configura **`OCR_SPACE_API_KEY`** en el dashboard de Render (no en el repo).

**SLA operativo:** mantener el endpoint en <=10s extremo a extremo.

```bash
curl -X POST "https://api-ocr-g2g4.onrender.com/ocr/extract" \
	-F "file=@documento.jpg" \
	-F "tramite=curp" \
	-F "lang=spa"

# Con preproceso visual (solo si lo necesitas; por defecto el servidor no lo aplica)
curl -X POST "https://api-ocr-g2g4.onrender.com/ocr/extract" \
	-F "file=@documento.jpg" \
	-F "tramite=curp" \
	-F "aplicar_preproceso_ocr=true"
```

Ejemplo de cuerpo de respuesta (estructura típica; `fields` depende del extractor):

```json
{
  "success": true,
	"tramite": "curp",
	"fields": [],
  "metadata": {
    "language": "spa",
		"ocr_source": "ocr_space",
		"ocr_ok": true,
		"processing_time": 1.23,
		"original_size": 456789,
		"compressed_size": 123456
	}
}
```

---

### `preprocess_light` (uso en `/ocr/extract`)

En [`preprocessing/enhance.py`](preprocessing/enhance.py): `preprocess_light` aplica **CLAHE → sombras → denoise** (y HSV opcional). **No** incluye binarización global/adaptativa (Sauvola/Otsu). En `/ocr/extract`, por default el preproceso está **desactivado** (`OCR_EXTRACT_APPLY_PREPROCESS=false`); actívalo con env o `aplicar_preproceso_ocr=true` si un trámite lo necesita.

**Investigación futura (no implementado):** saturación localizada (~+1 % en sombras tipo ~#898989, solo glifos), ROI de exclusión para logos — ver backlog en [`CAMBIOS_OCR_AIDA.md`](CAMBIOS_OCR_AIDA.md).

---

### Patrones regex principales (copiados del código)

[`extractors/curp.py`](extractors/curp.py):

```python
CURP_PATTERN = re.compile(r"\b([A-Z]{4}[0-9]{6}[HM][A-Z]{5}[0-9A-Z][0-9])\b", re.IGNORECASE)
```

[`extractors/ine.py`](extractors/ine.py): anclas ampliadas (credencial / instituto electoral), clave con texto compacto sin espacios, nombre tras etiqueta `NOMBRE` y ventana bajo credencial.

```python
CLAVE_ELECTOR_PATTERN = re.compile(r"\b([A-Z]{6}[0-9]{8}[A-Z][0-9]{3})\b")
```

[`extractors/acta.py`](extractors/acta.py) — folio:

```python
FOLIO_PATTERN = re.compile(r"\b(?:folio|no\.?)\s*:?\s*(\d+[-\w]*)\b", re.I)
```

[`extractors/certificado_medico.py`](extractors/certificado_medico.py) — constancia Cruz Roja / estudiante: anclas en `POR ESTE MEDIO SE DIRIGE A USTED` (nombre), bloque `C. ... AÑOS DE EDAD` (dirección) y bloque posterior a `CONVENGAN A LOS` (fecha, normalización `dd/mm/aaaa` con fallback textual).

Otros extractores usan patrones de fecha y nombre en los mismos archivos; ver el código fuente para la cadena exacta.

---

### Checklist de pruebas manuales sugeridas

- **CURP:** imagen con nombre legible cerca del CURP → el JSON incluye `nombre` razonable.
- **INE:** vigencia visible como años (`AAAA–AAAA` o texto “vigencia…”) → campo `vigencia` rellenado.
- **Acta:** folio precedido por “folio” o “no.” → `folio` presente.
- **`/ocr/prepare`:** solo preservación; `binarizar=true` o `modo=legacy` → **400**. Calibración visual: [docs/prepare_calibration_use_cases.txt](docs/prepare_calibration_use_cases.txt).
- **`/ocr/extract`:** misma forma de JSON; en fallo OCR validar respuesta `200` con campos nulos y `metadata.ocr_ok=false`.
- **`certificado_medico`:** validar `nombre_alumno`, `direccion` y `fecha_expedicion` (normalizada o fallback textual).

---

## Variables de entorno

| Variable | Descripción |
|----------|-------------|
| `PORT` | Puerto HTTP (Render lo define automáticamente). |
| `OCR_SPACE_API_KEY` | Clave de [OCR.space](https://ocr.space/). Es obligatoria para `/ocr/extract`. |
| `OCR_SPACE_TIMEOUT` | Timeout de OCR.space en segundos (default **5**). |
| `OCR_SPACE_MAX_UPLOAD_BYTES` | Límite objetivo de carga a OCR.space; si se supera se comprime automáticamente (default **950000**). |
| `OCR_EXTRACT_READ_MAX_DIM` | Techo al decodificar imagen en **`/ocr/extract`** (default **4096**, alineado con prepare). |
| `OCR_EXTRACT_DOWNSCALE_MAX_SIDE` | Si **> 0**, reduce el lado mayor antes del OCR; si **0**, no se redimensiona. |
| `OCR_NLMEANS_MAX_PIXELS` | Si `ancho×alto` supera este valor tras el preprocesado, se usa denoise **bilateral** en lugar de **nlmeans** en `preprocess_light` (default **700000**). |
| `OCR_PREPARE_READ_MAX_DIM` | Lado mayor máximo (px) al decodificar la imagen en **`/ocr/prepare`** cuando no se envía `lado_max_lectura` (default **4096**). |
| `OCR_PREPARE_JPEG_QUALITY` | Calidad JPEG de salida en **`/ocr/prepare`** cuando no se envía `calidad_jpeg` (1–100, default **100**). |
| `OCR_PREPARE_READ_MAX_DIM_CAP` | Máximo permitido para el campo multipart **`lado_max_lectura`** (default **4096**). |
| `OCR_PREPARE_READ_MIN_DIM` | Mínimo permitido para **`lado_max_lectura`** (default **256**). |
| `OCR_PREPARE_ALLOW_REQUEST_TUNING` | Si `false`, se ignoran **`calidad_jpeg`** y **`lado_max_lectura`** del formulario (solo config). Default: **false** (petición mínima). |
| `PREPARE_DEFAULT_BINARIZAR` | Debe ser **`false`** en AIDA: si es `true`, las peticiones sin `binarizar=false` explícito reciben **400**. |
| `OCR_PREPARE_SOFT_CLAHE` | Si `true`, **`/ocr/prepare`** aplica **CLAHE suave** tras HSV (solo RGB). Default **`false`** (contrato mínimo sin contraste adaptativo en prepare). Probar en **staging** (memoria/latencia) antes de producción. |
| `OCR_PREPARE_ENABLE_AUTO_ENHANCE` | Habilita modo opcional `auto_enhance` en `/ocr/prepare`. Default: `false`. |
| `OCR_PREPARE_ENHANCE_ENGINE_DEFAULT` | Motor de mejora por defecto (`opencv` o `image_enhancer`) cuando el cliente no envía `enhance_engine`. |
| `OCR_PREPARE_ENHANCE_TIMEOUT_SECONDS` | Tiempo objetivo máximo para mejora con `image_enhancer`; si falla o excede, fallback a original. |
| `OCR_PREPARE_IMAGE_ENHANCER_LUMA_PRESETS` | Si `true`, con `enhance_engine=image_enhancer` se elige preset según luminancia (OpenCV). Default: **true**. Si `false`, se usa el preset fijo histórico (`ie_legacy`). |
| `OCR_PREPARE_DIAGNOSTIC_HEADERS` | Si `true`, **`/ocr/prepare`** puede añadir cabeceras `X-OCR-Prepare-Luma-*` y `X-OCR-Prepare-Enhance-Bucket` / `X-OCR-Prepare-Enhance-Preset` cuando hay `auto_enhance`. Default: **false** (recomendado solo staging). |
| `OCR_PREPARE_SCHOOL_MEAN_GRAY_BAD_MAX` | Umbral del comparador escuela: media de gris en miniatura por debajo → se considera “mala luz” (default **118**; float). |
| `OCR_PREPARE_SCHOOL_WARM_RB_DELTA` | Umbral del comparador escuela: `mean(R) - mean(B)` en miniatura RGB por encima → se considera dominante cálida/naranja (default **24**; float). |
| `OCR_APPLY_HSV_SATURATION` | Si `true`, HSV leve en **`/ocr/prepare`** y en **`preprocess_light`** de **`/ocr/extract`** sin enviar flags en el form. Default: **true**. |
| `OCR_EXTRACT_APPLY_PREPROCESS` | Si `true`, activa `preprocess_light` por defecto en `/ocr/extract` (si no se envía `aplicar_preproceso_ocr`). Default: **false** (mejor con OCR.space en la mayoría de trámites). |
| `OCR_MAX_CONCURRENT_REQUESTS` | Máximo de peticiones **`/ocr/prepare`** y **`/ocr/extract`** en vuelo por proceso; si está lleno, **espera**. Default **10**. **0** = sin límite. |
| `OCR_RATE_LIMIT_REQUESTS` | Máximo de peticiones por IP en la ventana (solo `/ocr/*`). Default **30**. **0** = desactivado. |
| `OCR_RATE_LIMIT_WINDOW_SECONDS` | Ventana del rate limit en segundos. Default **600** (10 min). |

## Límites y formatos

- Tamaño máximo de subida acotado por [config.py](config.py) (`MAX_FILE_SIZE`, actualmente **20 MB**).
- Extensiones admitidas en validación: **`.jpg`**, **`.jpeg`**, **`.png`**, **`.tiff`**, **`.bmp`**. **No** se acepta PDF.

---

## Estructura del proyecto

```
├── main.py                 # Endpoints y orquestación
├── config.py               # Configuración por variables de entorno
├── requirements.txt
├── Dockerfile
├── utils/
│   ├── file_handling.py
│   ├── logging_config.py
│   ├── ocr_limits.py       # Rate limit por IP y semaforo de concurrencia (/ocr/*)
├── preprocessing/
│   ├── enhance.py          # Pipeline de imagen (prepare, preprocess_light, deskew_and_clean, …)
│   ├── quality.py        # Métricas ligeras para modo auto en /ocr/prepare
│   └── compression.py
├── extractors/             # Reglas por tipo de trámite
└── integration/
    └── ocr_space.py        # Cliente OCR.space (overlay + compresión)
```

---

## Integración AIDA

Contrato mínimo actual y curls: sección **Integración mínima AIDA (plug-and-play)** arriba y archivos en **`docs/OCR_AIDA_*.txt`**. Migración desde endpoints antiguos: **`handoff_aida_ocr_config.txt`** en la raíz del repo.

## Keep-Alive en Render Free (L-V)

Para evitar suspensión por inactividad en horario laboral, configura `cron-job.org` con:

- URL: `https://api-ocr-g2g4.onrender.com/health`
- Método: `GET`
- Cron: `*/5 8-20 * * 1-5`
- Zona horaria: `America/Mexico_City`

Fuera de ese horario no se envían pings; el servicio puede entrar en reposo.

---

## Dependencias principales

Ver [requirements.txt](requirements.txt): FastAPI, Uvicorn, OpenCV headless, NumPy, Pillow (JPEG + EXIF), `python-multipart`, `requests`.

---

## Licencia

GNU GPLv3 — ver [LICENSE](LICENSE).
