"""Tests modo simple escuela: clasificador, bundle neutro, gamma explícito en stack."""

import pytest

pytest.importorskip("cv2")
import numpy as np

from preprocessing.enhance import apply_prepare_experimental_stack
from preprocessing.prepare_school_presets import (
	SCHOOL_PREPARE_PRESETS,
	classify_school_lighting,
	is_server_default_prepare_bundle,
)


def test_classify_school_lighting_buckets() -> None:
	good = np.full((120, 120, 3), (250, 249, 248), dtype=np.uint8)
	assert classify_school_lighting(good) == "good"

	bad = np.full((120, 120, 3), (60, 60, 60), dtype=np.uint8)
	assert classify_school_lighting(bad) == "bad"

	orange = np.full((120, 120, 3), (240, 200, 180), dtype=np.uint8)
	assert classify_school_lighting(orange) == "orange"

	bad_orange = np.full((120, 120, 3), (90, 75, 60), dtype=np.uint8)
	assert classify_school_lighting(bad_orange) == "bad_orange"


def test_is_server_default_prepare_bundle() -> None:
	assert is_server_default_prepare_bundle(
		False,
		0.35,
		False,
		0.5,
		False,
		0.35,
		False,
		0.6,
		False,
		1.0,
		1.0,
		False,
	)
	assert not is_server_default_prepare_bundle(
		True,
		0.35,
		False,
		0.5,
		False,
		0.35,
		False,
		0.6,
		False,
		1.0,
		1.0,
		False,
	)


def test_school_presets_have_expected_bad_orange_desat() -> None:
	row = SCHOOL_PREPARE_PRESETS["bad_orange"]
	assert row.preparar_desaturacion_fuerza == 0.7
	assert row.preparar_balance_intensidad == 1.0
	assert row.preparar_gamma_valor == 0.5


def test_apply_prepare_experimental_stack_respects_gamma_valor() -> None:
	base = np.full((64, 64, 3), 180, dtype=np.uint8)
	dark = apply_prepare_experimental_stack(
		base.copy(),
		preparar_corregir_gamma=True,
		preparar_clahe_contraste=False,
		preparar_saturacion=1.0,
		preparar_nitidez=1.0,
		gamma_value=2.5,
	)[0]
	bright = apply_prepare_experimental_stack(
		base.copy(),
		preparar_corregir_gamma=True,
		preparar_clahe_contraste=False,
		preparar_saturacion=1.0,
		preparar_nitidez=1.0,
		gamma_value=0.5,
	)[0]
	assert float(np.mean(dark)) < float(np.mean(bright))
