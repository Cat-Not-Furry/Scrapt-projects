# extractors/comprobante.py
import re
from typing import Any, Dict, List, Tuple

from extractors.base import BaseExtractor
from extractors.coords_helpers import find_line_anchor
from extractors.name_helpers import pick_allcaps_name, pick_title_name

FECHA_PATTERN = re.compile(
	r"\b(\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\d{4}[-/]\d{1,2}[-/]\d{1,2})\b"
)
NAME_PATTERN = re.compile(
	r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)+"
)

_CFE_BLOCK = re.compile(
	r"CFE\b"
	r"|COMISI[OÓ]N\s+FEDERAL\s+DE\s+ELECTRICIDAD"
	r"|Comisi[oó]n\s+Federal"
	r"|TELMEX|TOTALPLAY|IZZI|IZZI\s*NET|MOVISTAR|AT&T|ATT\b"
	r"|AGUA|SAPAL|CESPT|GAS\s+NATURAL|NATURGY|GAS\b"
	r"|RECIBO|COMPROBANTE\s+DE\s+DOMICILIO|DOMICILIO\s+FISCAL|"
	r"SUMINISTRO|NO\.\s*DE\s*CUENTA|CUENTA\s+CONTRATO",
	re.I,
)
_STOP_DOMICILIO = re.compile(
	r"NO\.?\s*DE\s+SERVICIO|N[UÚ]M\.?\s+DE\s+SERVICIO|CUENTA|"
	r"RPU|MULTIPLICADOR|NO\.?\s+HILOS|PERIODO\s+FACTURADO|"
	r"PER[IÍ]ODO\s+FACTURADO|L[IÍ]MITE\s+DE\s+PAGO",
	re.I,
)
_ANCHOR_PERIODO = re.compile(
	r"MULTIPLICADOR|NO\.?\s+HILOS|PERIODO\s+FACTURADO|PER[IÍ]ODO\s+FACTURADO|"
	r"L[IÍ]MITE\s+DE\s+PAGO|VENCIMIENTO|FECHA\s+DE\s+EMISI[OÓ]N|EMISI[OÓ]N|"
	r"FECHA\s+L[IÍ]MITE",
	re.I,
)
_IMPRESION_PIE = re.compile(
	r"Fecha[,:]?\s+hora\s+y\s+lugar\s+de\s+impresi[oó]n",
	re.I,
)


def _normalize_newlines(text: str) -> str:
	return text.replace("\r\n", "\n").replace("\r", "\n")


def _lines(text: str) -> List[str]:
	return [ln.rstrip() for ln in _normalize_newlines(text).split("\n")]


def _cfe_block_bounds(lines_list: List[str]) -> Tuple[int, int]:
	start = -1
	for i, ln in enumerate(lines_list):
		if _CFE_BLOCK.search(ln):
			start = i
			break
	if start < 0:
		return 0, len(lines_list)
	end = min(len(lines_list), start + 45)
	return start, end


def _titular_y_direccion(lines_list: List[str], start: int, end: int) -> Tuple[str | None, str | None, float, float]:
	window = lines_list[start:end]
	titular = None
	dir_lines: list[str] = []
	seen_cfe = False
	for i, ln in enumerate(window):
		if not ln.strip():
			continue
		if _CFE_BLOCK.search(ln):
			seen_cfe = True
			continue
		if seen_cfe and re.search(
			r"Federal|Electricidad|CFE|Telmex|Totalplay|Izzi|Movistar|Recibo",
			ln,
			re.I,
		):
			continue
		if seen_cfe and titular is None:
			if re.search(r"sucursal|oficina|raz[oó]n\s+social", ln, re.I):
				continue
			if len(ln) > 6 and re.search(r"[A-Za-zÁÉÍÓÚÑ]", ln):
				titular = ln.strip()
				for j in range(i + 1, len(window)):
					dl = window[j].strip()
					if not dl:
						continue
					if _STOP_DOMICILIO.search(dl):
						break
					dir_lines.append(dl)
			break
	direccion = "\n".join(dir_lines).strip() if dir_lines else None
	tc = 0.82 if titular else 0.0
	dc = 0.78 if direccion and len(direccion) > 10 else (0.65 if direccion else 0.0)
	return titular, direccion, tc, dc


def _fecha_comprobante(text: str, lines_list: List[str]) -> Tuple[str | None, float]:
	n = _normalize_newlines(text)
	for i, ln in enumerate(lines_list):
		if _ANCHOR_PERIODO.search(ln):
			chunk = "\n".join(lines_list[i : min(i + 8, len(lines_list))])
			for m in FECHA_PATTERN.finditer(chunk):
				return m.group(1), 0.88
	if _IMPRESION_PIE.search(n):
		tail = n[_IMPRESION_PIE.search(n).end() :]
		m = FECHA_PATTERN.search(tail[:200])
		if m:
			return m.group(1), 0.72
	for m in FECHA_PATTERN.finditer(n):
		return m.group(1), 0.65
	return None, 0.0


def _titular_antes_direccion(lines_list: List[str]) -> Tuple[str | None, float]:
	first_dir = -1
	for i, ln in enumerate(lines_list):
		ll = ln.lower()
		if re.search(
			r"\bcalle\b|\bav\.|\bavenida\b|\bcol\.|\bcolonia\b|\bcp\b|c\.p\.|#\d|no\.\s*ext",
			ll,
		):
			first_dir = i
			break
	if first_dir <= 0:
		return None, 0.0
	prev = lines_list[first_dir - 1].strip()
	if len(prev) > 5 and re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]", prev):
		return prev, 0.68
	return None, 0.0


class ComprobanteExtractor(BaseExtractor):
	def empty_fields(self) -> Dict[str, Any]:
		return {
			"fecha_emision": self._field_null(),
			"direccion": self._field_null(),
			"nombre_titular": self._field_null(),
		}

	def extract_with_coords(
		self,
		text: str,
		lines: list[dict[str, Any]] | None = None,
		words: list[dict[str, Any]] | None = None,
	) -> Dict[str, Any]:
		_ = words
		if not lines:
			return self.extract(text)
		nombre_titular = None
		nombre_conf = 0.0
		direccion = None
		direccion_conf = 0.0
		fecha_emision = None
		fecha_conf = 0.0
		cfe_anchor = find_line_anchor(lines, [r"\bCFE\b", r"COMISION\s+FEDERAL\s+DE\s+ELECTRICIDAD"])
		if cfe_anchor:
			top = int(cfe_anchor.get("top", 0))
			cands = [ln for ln in lines if int(ln.get("top", 0)) > top + 15 and int(ln.get("top", 0)) < top + 220]
			cands.sort(key=lambda x: int(x.get("top", 0)))
			for ln in cands:
				t = ln.get("text", "").strip()
				if re.search(r"CALLE|COL|CP|NO\.\s*DE\s*SERVICIO|RMU|CUENTA", t, re.I):
					break
				if len(t) > 6:
					nombre_titular = t
					nombre_conf = 0.84
					break
			dir_lines = []
			for ln in cands:
				t = ln.get("text", "").strip()
				if re.search(r"NO\.\s*DE\s*SERVICIO|RMU|CUENTA|L[IÍ]MITE\s+DE\s+PAGO", t, re.I):
					break
				if re.search(r"CALLE|COL|CP|C\.P|HGO|JOYA|SANTIAGO|LT|LTE", t, re.I):
					dir_lines.append(t)
			if dir_lines:
				direccion = "\n".join(dir_lines)
				direccion_conf = 0.86
		fecha_anchor = find_line_anchor(lines, [r"L[IÍ]MITE\s+DE\s+PAGO"])
		if fecha_anchor:
			t = fecha_anchor.get("text", "")
			m = re.search(r"(\d{1,2}\s+[A-Z]{3}\s+\d{2})", t, re.I)
			if m:
				fecha_emision = m.group(1).upper()
				fecha_conf = 0.9
		fallback = self.extract(text)
		if not nombre_titular:
			nombre_titular = fallback["nombre_titular"]["value"]
			nombre_conf = fallback["nombre_titular"]["confidence"]
		if not direccion:
			direccion = fallback["direccion"]["value"]
			direccion_conf = fallback["direccion"]["confidence"]
		if not fecha_emision:
			fecha_emision = fallback["fecha_emision"]["value"]
			fecha_conf = fallback["fecha_emision"]["confidence"]
		return {
			"fecha_emision": {"value": fecha_emision, "confidence": fecha_conf},
			"direccion": {"value": direccion, "confidence": direccion_conf},
			"nombre_titular": {"value": nombre_titular, "confidence": nombre_conf},
		}

	def extract(self, text: str) -> Dict[str, Any]:
		n = _normalize_newlines(text)
		lines_list = _lines(n)
		a, b = _cfe_block_bounds(lines_list)
		sub = lines_list[a:b]

		nombre_titular, direccion, nombre_conf, direccion_conf = _titular_y_direccion(
			lines_list, a, b
		)
		if not nombre_titular:
			nt, nc = _titular_antes_direccion(lines_list)
			if nt:
				nombre_titular, nombre_conf = nt, max(nombre_conf, nc)
		fecha_emision, fecha_conf = _fecha_comprobante(n, lines_list)

		text_lower = n.lower()
		if not nombre_titular:
			titular_match = re.search(
				r"(?:domicilio|titular)\s*:?\s*(.+?)(?:\s*(?:calle|cp|fecha)|\s*$)",
				n,
				re.I,
			)
			if titular_match:
				nombre_titular = titular_match.group(1).strip()
				nombre_conf = 0.75
		if not nombre_titular and not any(
			c in text_lower for c in ["comprobante", "cfdi", "factura"]
		):
			name_match = NAME_PATTERN.search(n)
			if name_match:
				nombre_titular = name_match.group()
				nombre_conf = 0.6
		if not nombre_titular:
			nm, c = pick_title_name(n)
			if nm:
				nombre_titular, nombre_conf = nm, max(nombre_conf, c)
			else:
				nm, c = pick_allcaps_name(n, 0.55)
				if nm:
					nombre_titular, nombre_conf = nm, max(nombre_conf, c)

		if not direccion:
			DIRECCION_INDICATORS = ("calle", "av.", "avenida", "col.", "colonia", "cp", "no.")
			if any(ind in text_lower for ind in DIRECCION_INDICATORS):
				for line in lines_list:
					line_lower = line.lower()
					if any(ind in line_lower for ind in DIRECCION_INDICATORS) or re.search(
						r"\d{5}", line
					):
						direccion = line.strip()
						direccion_conf = 0.75
						break
			elif re.search(r"\d{5}", n):
				direccion_match = re.search(r".{10,80}\d{5}.{0,30}", n)
				if direccion_match:
					direccion = direccion_match.group().strip()
					direccion_conf = 0.6
		if direccion is None:
			for line in sub:
				line_stripped = line.strip()
				if len(line_stripped) >= 25 and re.search(r"\d", line_stripped):
					direccion = line_stripped
					direccion_conf = max(direccion_conf, 0.5)
					break

		return {
			"fecha_emision": {"value": fecha_emision, "confidence": fecha_conf},
			"direccion": {"value": direccion, "confidence": direccion_conf},
			"nombre_titular": {"value": nombre_titular, "confidence": nombre_conf},
		}
