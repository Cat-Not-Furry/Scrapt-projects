# preprocessing/enhance.py
import logging
import os
import tempfile
import time
from dataclasses import dataclass

import cv2
import numpy as np

from config import OCR_NLMEANS_MAX_PIXELS
from preprocessing.quality import compute_white_distance_metrics

logger = logging.getLogger(__name__)

# Contrato AIDA: la app envía imagen ya orientada y con saturación adecuada; en servidor no se endereza
# por Hough ni se fuerza retrato; reparación de borde y HSV opcionales (por defecto desactivados).
USE_CORRECT_SKEW = False
USE_REPAIR_BOTTOM_EDGE = False

try:
    from spellchecker import SpellChecker
except ImportError:
    SpellChecker = None
    logger.warning("Spellchecker no instalado, funciones de corrección no disponibles.")


def correct_skew(image: np.ndarray) -> np.ndarray:
    """Corrige la inclinación del documento."""
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image

    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLines(edges, 1, np.pi / 180, 200)
    if lines is not None:
        angles = []
        for rho, theta in lines[:, 0]:
            angle = np.rad2deg(theta) - 90
            angles.append(angle)
        median_angle = np.median(angles)
        if abs(median_angle) > 0.5:
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, median_angle, 1.0)
            rotated = cv2.warpAffine(
                image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE
            )
            return rotated
    return image


def remove_noise(image: np.ndarray, method="nlmeans") -> np.ndarray:
    """Elimina ruido usando diferentes métodos."""
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image

    logger.debug(f"remove_noise - shape: {image.shape}")

    if method == "nlmeans":
        return cv2.fastNlMeansDenoising(
            gray, h=30, templateWindowSize=7, searchWindowSize=21
        )
    elif method == "gaussian":
        return cv2.GaussianBlur(gray, (5, 5), 0)
    elif method == "median":
        return cv2.medianBlur(gray, 5)
    elif method == "bilateral":
        return cv2.bilateralFilter(gray, 9, 75, 75)
    else:
        return gray


def resize_for_ocr(image: np.ndarray, target_width=2000) -> np.ndarray:
    h, w = image.shape[:2]
    if w < target_width:
        scale = target_width / w
        new_size = (target_width, int(h * scale))
        return cv2.resize(image, new_size, interpolation=cv2.INTER_CUBIC)
    return image


def sauvola_threshold(
    img: np.ndarray, window_size: int = 31, k: float = 0.15
) -> np.ndarray:
    """
    Aplica umbral de Sauvola a una imagen en escala de grises.
    Basado en la fórmula: T = mean * (1 + k * ((std / R) - 1))
    """
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # Convertir a float32 para cálculos precisos
    img_float = img.astype(np.float32)

    # Media local
    mean = cv2.boxFilter(img_float, -1, (window_size, window_size))

    # Cuadrado de la media local
    sqmean = cv2.boxFilter(img_float**2, -1, (window_size, window_size))

    # Desviación estándar local (evitar valores negativos por redondeo)
    std = np.sqrt(np.abs(sqmean - mean**2))

    R = 128  # Rango dinámico estándar para imágenes de 8 bits
    threshold = mean * (1 + k * ((std / R) - 1))

    # Aplicar umbral: píxeles mayores que el umbral se convierten en 255
    binary = (img > threshold).astype(np.uint8) * 255
    return binary


def binarize(
    image: np.ndarray,
    method="adaptive",
    window: int = 31,
    k: float = 0.15,
) -> np.ndarray:
    """Binarización avanzada: Otsu, Adaptive o Sauvola (window/k solo para Sauvola)."""
    gray = image if len(image.shape) == 2 else cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    if method == "otsu":
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    elif method == "adaptive":
        thresh = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 15, 2
        )
    elif method == "sauvola":
        thresh = sauvola_threshold(gray, window_size=window, k=k)
    else:
        thresh = gray
    return thresh


def remove_shadows(image: np.ndarray) -> np.ndarray:
    """Elimina sombras mediante corrección de iluminación."""
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    dilated = cv2.dilate(gray, np.ones((5, 5), np.uint8))
    blurred = cv2.medianBlur(dilated, 21)
    diff = 255 - cv2.absdiff(gray, blurred)
    norm = cv2.normalize(diff, None, 0, 255, cv2.NORM_MINMAX)
    return norm


def sharpen_gray(gray: np.ndarray, intensity: float = 1.0) -> np.ndarray:
    """Unsharp mask; intensity=1.0 reproduce el efecto previo (sigma 1.2, 1.15 / -0.15)."""
    if intensity <= 0:
        return gray
    sigma = 1.2
    alpha = 1.15 * intensity + (1.0 - intensity)
    beta = -0.15 * intensity
    blurred = cv2.GaussianBlur(gray, (0, 0), sigmaX=sigma)
    return cv2.addWeighted(gray, alpha, blurred, beta, 0)


def apply_clahe(image: np.ndarray) -> np.ndarray:
    """Aplica CLAHE para mejorar contraste."""
    lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l = clahe.apply(l)
    lab = cv2.merge([l, a, b])
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
    return enhanced


def apply_clahe_prepare(image: np.ndarray, clip_limit: float = 1.5) -> np.ndarray:
    """CLAHE suave solo para /ocr/prepare (plantilla PDF); no altera apply_clahe usado en OCR."""
    lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(8, 8))
    l = clahe.apply(l)
    lab = cv2.merge([l, a, b])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)


# --- Stack experimental opcional en /ocr/prepare (multipart; todos off por defecto) ---


def white_balance_simple_rgb(image: np.ndarray, intensity: float) -> np.ndarray:
	"""
	Balance de blancos tipo gray-world. intensity 0 = sin cambio, 1 = corrección completa.
	Entrada/salida RGB uint8.
	"""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	t = float(np.clip(intensity, 0.0, 1.0))
	if t <= 1e-9:
		return image
	img = image.astype(np.float32)
	mr = float(np.mean(img[:, :, 0]))
	mg = float(np.mean(img[:, :, 1]))
	mb = float(np.mean(img[:, :, 2]))
	m = (mr + mg + mb) / 3.0
	if m < 1e-3:
		return image
	sr, sg, sb = m / max(mr, 1e-3), m / max(mg, 1e-3), m / max(mb, 1e-3)
	balanced = img.copy()
	balanced[:, :, 0] *= sr
	balanced[:, :, 1] *= sg
	balanced[:, :, 2] *= sb
	balanced = np.clip(balanced, 0.0, 255.0)
	out = (1.0 - t) * img + t * balanced
	return np.clip(out, 0, 255).astype(np.uint8)


def desaturate_selective_rgb(
	image: np.ndarray,
	strength: float,
	sat_threshold: float | None = None,
) -> np.ndarray:
	"""
	Reduce saturación (canal S en HSV OpenCV) principalmente donde S supera un umbral.
	strength 0–1: cuánto se atenúa S en píxeles por encima del umbral.
	sat_threshold: si None, usa percentil 70 de S en la imagen.
	"""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	k = float(np.clip(strength, 0.0, 1.0))
	if k <= 1e-9:
		return image
	hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
	s = hsv[:, :, 1]
	if sat_threshold is None:
		thr = float(np.percentile(s, 70.0))
	else:
		thr = float(np.clip(sat_threshold, 0.0, 255.0))
	mask = np.clip((s - thr) / max(255.0 - thr, 1e-3), 0.0, 1.0)
	# Suavizar transición: atenuar S donde mask>0
	f = 1.0 - k * mask
	hsv[:, :, 1] = np.clip(s * f, 0, 255)
	return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)


def apply_gamma_rgb(image: np.ndarray, gamma: float) -> np.ndarray:
	"""Corrección gamma en RGB uint8; gamma < 1 aclara."""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	g = float(max(0.05, min(gamma, 5.0)))
	inv = 1.0 / g
	table = np.array([(i / 255.0) ** inv * 255.0 for i in range(256)], dtype=np.uint8)
	return cv2.LUT(image, table)


def adjust_saturation_rgb(image: np.ndarray, factor: float) -> np.ndarray:
	"""Factor 1.0 = sin cambio. OpenCV HSV usa H 0-179 en uint8."""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	f = float(max(0.0, min(factor, 3.0)))
	hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
	hsv[:, :, 1] = np.clip(hsv[:, :, 1] * f, 0, 255)
	return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)


def unsharp_rgb_nitidez(image: np.ndarray, strength: float) -> np.ndarray:
	"""Unsharp mask; strength 0 = noop (misma idea que sharpen del plan)."""
	if strength <= 1e-6:
		return image
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	blurred = cv2.GaussianBlur(image, (0, 0), 2.0)
	return cv2.addWeighted(image, 1.0 + strength, blurred, -strength, 0)


def binarize_otsu_rgb(image: np.ndarray) -> np.ndarray:
	"""Binarización Otsu; salida RGB 3 canales."""
	if len(image.shape) == 2:
		gray = image
	else:
		gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
	_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
	return cv2.cvtColor(binary, cv2.COLOR_GRAY2RGB)


def apply_prepare_experimental_stack(
	image: np.ndarray,
	*,
	preparar_balance_blancos: bool = False,
	preparar_balance_intensidad: float = 0.35,
	preparar_corregir_iluminacion: bool = False,
	preparar_iluminacion_intensidad: float = 0.5,
	preparar_desaturacion_selectiva: bool = False,
	preparar_desaturacion_fuerza: float = 0.35,
	preparar_corregir_gamma: bool = False,
	preparar_clahe_contraste: bool = False,
	preparar_saturacion: float = 1.0,
	preparar_nitidez: float = 1.0,
	preparar_binarizar_otsu: bool = False,
	gamma_value: float = 0.6,
) -> tuple[np.ndarray, list[str]]:
	"""
	Pipeline opcional tras read_image: balance, iluminación, gamma, saturación,
	desaturación selectiva, CLAHE, nitidez, Otsu.
	Devuelve (imagen, lista de pasos aplicados para logs/cabeceras).
	"""
	out = image
	steps: list[str] = []
	if preparar_balance_blancos:
		out = white_balance_simple_rgb(out, float(preparar_balance_intensidad))
		steps.append("wb")
	if preparar_corregir_iluminacion:
		out = even_out_background_rgb(out, effect_strength=float(preparar_iluminacion_intensidad))
		steps.append("illum")
	if preparar_corregir_gamma:
		out = apply_gamma_rgb(out, gamma_value)
		steps.append("gamma")
	if abs(float(preparar_saturacion) - 1.0) > 1e-6:
		out = adjust_saturation_rgb(out, float(preparar_saturacion))
		steps.append("saturation")
	if preparar_desaturacion_selectiva:
		out = desaturate_selective_rgb(out, float(preparar_desaturacion_fuerza), sat_threshold=None)
		steps.append("desat_sel")
	if preparar_clahe_contraste:
		out = apply_clahe(out)
		steps.append("clahe")
	if float(preparar_nitidez) > 1.0 + 1e-6:
		out = unsharp_rgb_nitidez(out, float(preparar_nitidez) - 1.0)
		steps.append("sharpness")
	if preparar_binarizar_otsu:
		out = binarize_otsu_rgb(out)
		steps.append("otsu")
	return out, steps


# Umbrales mean_gray [0..255] para /ocr/prepare. near_white alineado con _MEAN_NEAR_WHITE en quality.py.
_PREPARE_LUMA_NEAR_WHITE = 248.0
_PREPARE_LUMA_DARK_MAX = 95.0
_PREPARE_LUMA_MEDIUM_MAX = 155.0
_PREPARE_LUMA_STATS_MAX_SIDE = 512


@dataclass(frozen=True)
class PrepareLumaClassification:
	"""Métricas de luminancia para presets de mejora (OpenCV e image_enhancer)."""

	mean_gray: float
	contrast_std: float
	bucket: str


def classify_prepare_luma_bucket(mean_gray: float) -> str:
	"""Devuelve dark | medium | light | near_white."""
	if mean_gray >= _PREPARE_LUMA_NEAR_WHITE:
		return "near_white"
	if mean_gray < _PREPARE_LUMA_DARK_MAX:
		return "dark"
	if mean_gray < _PREPARE_LUMA_MEDIUM_MAX:
		return "medium"
	return "light"


def compute_prepare_luma_metrics(
	image: np.ndarray,
	max_side_for_stats: int = _PREPARE_LUMA_STATS_MAX_SIDE,
) -> tuple[float, float]:
	"""
	Media y desviación en gris sobre miniatura (mismo criterio que classify) para velocidad.
	"""
	if len(image.shape) != 3 or image.shape[2] != 3:
		gray = image if len(image.shape) == 2 else image
	else:
		gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
	h, w = gray.shape[:2]
	side = max(h, w)
	if side > max_side_for_stats and side > 0:
		scale = max_side_for_stats / float(side)
		new_w = max(1, int(round(w * scale)))
		new_h = max(1, int(round(h * scale)))
		gray = cv2.resize(gray, (new_w, new_h), interpolation=cv2.INTER_AREA)
	mean_gray = float(np.mean(gray))
	contrast_std = float(np.std(gray))
	return mean_gray, contrast_std


def classify_prepare_luma(
	image: np.ndarray,
	max_side_for_stats: int = _PREPARE_LUMA_STATS_MAX_SIDE,
) -> PrepareLumaClassification:
	mean_gray, contrast_std = compute_prepare_luma_metrics(image, max_side_for_stats)
	bucket = classify_prepare_luma_bucket(mean_gray)
	return PrepareLumaClassification(
		mean_gray=mean_gray,
		contrast_std=contrast_std,
		bucket=bucket,
	)


# Preset histórico único (compatibilidad si OCR_PREPARE_IMAGE_ENHANCER_LUMA_PRESETS=false).
IMAGE_ENHANCER_PARAMS_LEGACY: dict[str, int | float] = {
	"denoise_strength": 6,
	"brightness": 1.1,
	"contrast": 1.1,
	"sharpness": 1.2,
	"color": 1.0,
	"gamma": 1.0,
}

# Presets por bucket para image_enhancer (ajuste conservador en near_white).
IMAGE_ENHANCER_PRESET_BY_BUCKET: dict[str, tuple[dict[str, int | float], str]] = {
	"dark": (
		{
			"denoise_strength": 8,
			"brightness": 1.18,
			"contrast": 1.15,
			"sharpness": 1.25,
			"color": 1.0,
			"gamma": 1.05,
		},
		"ie_dark",
	),
	"medium": (
		{
			"denoise_strength": 6,
			"brightness": 1.1,
			"contrast": 1.1,
			"sharpness": 1.2,
			"color": 1.0,
			"gamma": 1.0,
		},
		"ie_medium",
	),
	"light": (
		{
			"denoise_strength": 5,
			"brightness": 1.06,
			"contrast": 1.06,
			"sharpness": 1.12,
			"color": 1.0,
			"gamma": 1.0,
		},
		"ie_light",
	),
	"near_white": (
		{
			"denoise_strength": 4,
			"brightness": 1.02,
			"contrast": 1.02,
			"sharpness": 1.05,
			"color": 1.0,
			"gamma": 1.0,
		},
		"ie_near_white",
	),
}


def image_enhancer_params_for_bucket(bucket: str) -> tuple[dict[str, int | float], str]:
	"""Params y id de preset para logging/cabeceras."""
	row = IMAGE_ENHANCER_PRESET_BY_BUCKET.get(bucket)
	if row is None:
		return IMAGE_ENHANCER_PRESET_BY_BUCKET["medium"]
	return row


def enhance_photometric_opencv(
	image: np.ndarray,
	luma_bucket: str | None = None,
) -> np.ndarray:
	"""
	Mejora fotométrica opcional basada en OpenCV.
	Entrada/salida RGB uint8. Si luma_bucket es None, se clasifica sobre la propia imagen.
	"""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	bucket = luma_bucket if luma_bucket is not None else classify_prepare_luma(image).bucket
	# clipLimit, bilateral (d, sc, ss), gaussian_sigma, unsharp (alpha, beta)
	profiles: dict[str, tuple[float, int, int, int, float, float, float]] = {
		"dark": (2.2, 9, 85, 85, 1.5, 1.25, -0.25),
		"medium": (2.0, 9, 75, 75, 1.5, 1.2, -0.2),
		"light": (1.65, 9, 60, 60, 1.45, 1.12, -0.12),
		"near_white": (1.25, 7, 45, 45, 1.2, 1.06, -0.06),
	}
	clip, bd, bsc, bss, gsig, alpha, beta = profiles.get(bucket, profiles["medium"])
	lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
	l_ch, a_ch, b_ch = cv2.split(lab)
	clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(8, 8))
	l_ch = clahe.apply(l_ch)
	lab = cv2.merge([l_ch, a_ch, b_ch])
	img = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
	img = cv2.bilateralFilter(img, bd, bsc, bss)
	blurred = cv2.GaussianBlur(img, (0, 0), sigmaX=gsig)
	return cv2.addWeighted(img, alpha, blurred, beta, 0)


def opencv_enhance_preset_id(bucket: str) -> str:
	return f"opencv_{bucket}"


def enhance_photometric_image_enhancer(
	image: np.ndarray,
	timeout_seconds: int = 2,
	params: dict[str, int | float] | None = None,
) -> tuple[np.ndarray | None, str]:
	"""
	Aplica ImageEnhancer sobre archivo temporal.
	Retorna (imagen_mejorada_o_none, motivo).
	Si params es None, usa IMAGE_ENHANCER_PARAMS_LEGACY.
	"""
	start = time.time()
	tmp_input_path = None
	tmp_output_path = None
	try:
		from image_enhancer import ImageEnhancer
	except Exception as exc:
		return None, f"import_error:{exc}"
	try:
		if len(image.shape) != 3 or image.shape[2] != 3:
			return None, "invalid_shape"
		with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmp_input:
			tmp_input_path = tmp_input.name
		ok = cv2.imwrite(tmp_input_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
		if not ok:
			return None, "write_input_failed"
		if params is None:
			params = dict(IMAGE_ENHANCER_PARAMS_LEGACY)
		enhancer = ImageEnhancer()
		tmp_output_path = enhancer.enhance(tmp_input_path, params)
		if not tmp_output_path or not os.path.exists(tmp_output_path):
			return None, "enhancer_no_output"
		elapsed = time.time() - start
		if elapsed > max(1, timeout_seconds):
			return None, f"enhancer_timeout:{elapsed:.2f}s"
		enhanced_np = cv2.imread(tmp_output_path, cv2.IMREAD_COLOR)
		if enhanced_np is None:
			return None, "read_output_failed"
		return cv2.cvtColor(enhanced_np, cv2.COLOR_BGR2RGB), "ok"
	except Exception as exc:
		return None, f"enhancer_error:{exc}"
	finally:
		for path in (tmp_input_path, tmp_output_path):
			if path and os.path.exists(path):
				try:
					os.unlink(path)
				except OSError:
					pass


def even_out_background_rgb(
	image: np.ndarray,
	effect_strength: float = 1.0,
	luma_mix_original: float = 0.42,
	luma_mix_flat: float = 0.58,
) -> np.ndarray:
	"""
	Aclara el fondo hacia blanco usando estimación de iluminación (Gaussian grande en L),
	mezclando con L original para conservar trazo en texto y sellos.
	Entrada y salida RGB uint8.
	effect_strength 0 = imagen original, 1 = aplicar resultado completo (mezcla RGB final).
	luma_mix_original / luma_mix_flat: pesos internos en L (default histórico 0.42 / 0.58).
	"""
	if len(image.shape) != 3 or image.shape[2] != 3:
		raise ValueError("even_out_background_rgb requiere imagen RGB")
	s = float(np.clip(effect_strength, 0.0, 1.0))
	if s <= 1e-9:
		return image
	w0 = float(luma_mix_original)
	w1 = float(luma_mix_flat)
	sumw = w0 + w1
	if sumw > 1e-6:
		w0, w1 = w0 / sumw, w1 / sumw
	lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
	l, a, b_ch = cv2.split(lab)
	h, w = l.shape
	sigma = float(max(h, w)) / 28.0
	sigma = max(3.0, min(sigma, 45.0))
	bg = cv2.GaussianBlur(l, (0, 0), sigmaX=sigma).astype(np.float32)
	bg = np.maximum(bg, 42.0)
	lf = l.astype(np.float32)
	l_flat = np.clip(lf * (242.0 / bg), 0, 255).astype(np.uint8)
	l_out = cv2.addWeighted(l, w0, l_flat, w1, 0)
	lab2 = cv2.merge([l_out, a, b_ch])
	proc = cv2.cvtColor(lab2, cv2.COLOR_LAB2RGB)
	if s >= 1.0 - 1e-6:
		return proc
	return cv2.addWeighted(
		image.astype(np.float32),
		1.0 - s,
		proc.astype(np.float32),
		s,
		0,
	).astype(np.uint8)


def repair_bottom_edge_rgb(
	image: np.ndarray,
	band_frac: float = 0.07,
	dark_threshold: float = 48.0,
	sample_rows: int = 12,
) -> np.ndarray:
	"""Rellena franja inferior oscura (gutter) con color medio del papel encima; solo bordes."""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	h, w = image.shape[:2]
	band_h = max(2, int(h * band_frac))
	y0 = max(0, h - band_h)
	strip = image[y0:h, :, :]
	gray_strip = cv2.cvtColor(strip, cv2.COLOR_RGB2GRAY)
	if float(np.mean(gray_strip)) > dark_threshold:
		return image
	y_sample_end = y0
	y_sample_start = max(0, y_sample_end - sample_rows)
	if y_sample_start >= y_sample_end:
		return image
	roi = image[y_sample_start:y_sample_end, :, :]
	color = np.mean(roi.reshape(-1, 3), axis=0).astype(np.uint8)
	out = image.copy()
	out[y0:h, :, :] = color
	return out


def apply_hs_saturation_scale_rgb(image: np.ndarray, s_mult: float) -> np.ndarray:
	"""Escala canal S en HSV (RGB uint8); s_mult ~1 sin cambio."""
	if len(image.shape) != 3 or image.shape[2] != 3:
		return image
	if s_mult <= 0 or abs(s_mult - 1.0) < 1e-6:
		return image
	hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
	h_ch, s_ch, v_ch = cv2.split(hsv)
	s_f = s_ch.astype(np.float32) * float(s_mult)
	s_ch = np.clip(s_f, 0, 255).astype(np.uint8)
	hsv2 = cv2.merge([h_ch, s_ch, v_ch])
	return cv2.cvtColor(hsv2, cv2.COLOR_HSV2RGB)


def downscale_max_side(image: np.ndarray, max_side: int) -> np.ndarray:
    """Reduce la imagen si el lado mayor supera max_side (útil solo antes de Tesseract)."""
    if max_side <= 0:
        return image
    h, w = image.shape[:2]
    m = max(h, w)
    if m <= max_side:
        return image
    scale = max_side / m
    new_w = max(1, int(w * scale))
    new_h = max(1, int(h * scale))
    return cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_AREA)


def preprocess_light(
	image: np.ndarray,
	correct_skew_flag: bool | None = None,
	apply_hs_saturation: bool = False,
) -> np.ndarray:
	"""
	Pipeline ligero para OCR: opcionalmente skew/reparación/HSV, CLAHE, sombras, ruido.
	Por defecto (AIDA) sin HSV; activar con apply_hs_saturation o vía main (form/env).
	"""
	if correct_skew_flag is None:
		correct_skew_flag = USE_CORRECT_SKEW
	if correct_skew_flag:
		image = correct_skew(image)
	if len(image.shape) == 3 and image.shape[2] == 3:
		if USE_REPAIR_BOTTOM_EDGE:
			image = repair_bottom_edge_rgb(image)
		if apply_hs_saturation:
			wm = compute_white_distance_metrics(image, with_hsv_mult=True)
			image = apply_hs_saturation_scale_rgb(image, wm["s_mult"])
	image = apply_clahe(image)
	image = remove_shadows(image)
	h, w = image.shape[:2]
	if h * w > OCR_NLMEANS_MAX_PIXELS:
		image = remove_noise(image, method="bilateral")
		logger.debug("preprocess_light: denoise bilateral (%d px)", h * w)
	else:
		image = remove_noise(image, method="nlmeans")
	return image


def prepare_denoise(image: np.ndarray, binarizar: bool) -> np.ndarray:
    """Denoise para /ocr/prepare: bilateral si no se binariza (logos); nlmeans si binarizar."""
    if not binarizar:
        return remove_noise(image, method="bilateral")
    return remove_noise(image, method="nlmeans")


def deskew_and_clean(
    image: np.ndarray, binarization_method: str = "auto"
) -> np.ndarray:
    img = correct_skew(image)
    # Mejora de contraste (opcional, se puede activar con flag)
    img = cv2.convertScaleAbs(img, alpha=1.3, beta=0)
    img = remove_shadows(img)
    img = remove_noise(img, method="nlmeans")

    # Binarización
    if binarization_method == "adaptive":
        img = binarize(img, method="adaptive")
    elif binarization_method == "sauvola":
        img = binarize(img, method="sauvola")
    else:  # auto
        img = binarize(img, method="sauvola" if img.mean() < 200 else "adaptive")

    # Cerrar pequeños huecos en caracteres
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)
    return img


def detect_document_contour(image: np.ndarray) -> np.ndarray:
    """Detecta el contorno más grande (probable documento) y lo recorta en perspectiva."""
    h0, w0 = image.shape[:2]
    img_area = float(h0 * w0)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 75, 200)

    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return image

    # Tomar el contorno más grande
    largest_contour = max(contours, key=cv2.contourArea)
    if cv2.contourArea(largest_contour) < 0.10 * img_area:
        return image
    peri = cv2.arcLength(largest_contour, True)
    approx = cv2.approxPolyDP(largest_contour, 0.05 * peri, True)

    # Si tiene 4 puntos, asumimos que es el documento
    if len(approx) == 4:
        # Ordenar puntos: superior-izquierdo, superior-derecho, inferior-derecho, inferior-izquierdo
        pts = approx.reshape(4, 2)
        rect = np.zeros((4, 2), dtype="float32")
        s = pts.sum(axis=1)
        rect[0] = pts[np.argmin(s)]  # superior-izquierdo
        rect[2] = pts[np.argmax(s)]  # inferior-derecho
        diff = np.diff(pts, axis=1)
        rect[1] = pts[np.argmin(diff)]  # superior-derecho
        rect[3] = pts[np.argmax(diff)]  # inferior-izquierdo

        (tl, tr, br, bl) = rect
        widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
        widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
        maxWidth = max(int(widthA), int(widthB))

        heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
        heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
        maxHeight = max(int(heightA), int(heightB))

        dst = np.array(
            [
                [0, 0],
                [maxWidth - 1, 0],
                [maxWidth - 1, maxHeight - 1],
                [0, maxHeight - 1],
            ],
            dtype="float32",
        )

        M = cv2.getPerspectiveTransform(rect, dst)
        warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
        return warped
    return image


def correct_spelling(text: str, lang="es") -> str:
    if SpellChecker is None:
        return text
    spell = SpellChecker(language=lang)
    words = text.split()
    corrected = [spell.correction(w) if spell.correction(w) else w for w in words]
    return " ".join(corrected)
