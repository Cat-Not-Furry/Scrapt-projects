# extractors/certificado_medico.py
"""Constancia de salud tipo Cruz Roja para estudiante (nombre, dirección y fecha)."""

import datetime
import re
import unicodedata
from typing import Any, Dict, List

from extractors.base import BaseExtractor
from extractors.coords_helpers import find_line_anchor, line_below_anchor
from extractors.name_helpers import pick_allcaps_name, pick_title_name

FECHA_DIGITAL_PATTERN = re.compile(
	r"\b(\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\d{4}[-/]\d{1,2}[-/]\d{1,2})\b"
)
ANCHOR_NOMBRE = re.compile(r"POR\s+ESTE\s+MEDIO\s+SE\s+DIRIGE\s+A\s+USTED", re.I)
ANCHOR_DIRECCION = re.compile(
	r"C\.\s*AÑOS\s+DE\s+EDAD|C\.\s*ANOS\s+DE\s+EDAD|"
	r"AÑOS\s+DE\s+EDAD\s+CON|ANOS\s+DE\s+EDAD\s+CON|"
	r"DOMICILIO\s+EN|CON\s+DOMICILIO\s+EN",
	re.I,
)
_CERT_NAME_BLACKLIST = re.compile(
	r"CRUZ\s*ROJA|MEXICANA|INSTITUTO|MEDIC[OA]|MÉDIC[OA]|\bDR\.|DOCTOR[A]?|"
	r"SEAMOS\s+TODOS|AIDA|EL\s+QUE\s+SUSCRIBE",
	re.I,
)
ANCHOR_FECHA = re.compile(r"CONVENGAN\s+A\s+LOS", re.I)
STOP_DIRECCION = re.compile(
	r"SU\s+TIPO\s+DE\s+SANGRE|OBSERVACIONES|GRUPO|RH|PESO|TALLA|TA:",
	re.I,
)

MONTHS = {
	"ENERO": 1,
	"FEBRERO": 2,
	"MARZO": 3,
	"ABRIL": 4,
	"MAYO": 5,
	"JUNIO": 6,
	"JULIO": 7,
	"AGOSTO": 8,
	"SEPTIEMBRE": 9,
	"OCTUBRE": 10,
	"NOVIEMBRE": 11,
	"DICIEMBRE": 12,
}

UNITS = {
	"CERO": 0,
	"UNO": 1,
	"UN": 1,
	"UNA": 1,
	"DOS": 2,
	"TRES": 3,
	"CUATRO": 4,
	"CINCO": 5,
	"SEIS": 6,
	"SIETE": 7,
	"OCHO": 8,
	"NUEVE": 9,
}

SPECIALS = {
	"DIEZ": 10,
	"ONCE": 11,
	"DOCE": 12,
	"TRECE": 13,
	"CATORCE": 14,
	"QUINCE": 15,
	"DIECISEIS": 16,
	"DIECISIETE": 17,
	"DIECIOCHO": 18,
	"DIECINUEVE": 19,
	"VEINTE": 20,
	"VEINTIUNO": 21,
	"VEINTIDOS": 22,
	"VEINTITRES": 23,
	"VEINTICUATRO": 24,
	"VEINTICINCO": 25,
	"VEINTISEIS": 26,
	"VEINTISIETE": 27,
	"VEINTIOCHO": 28,
	"VEINTINUEVE": 29,
}

TENS = {
	"TREINTA": 30,
	"CUARENTA": 40,
	"CINCUENTA": 50,
	"SESENTA": 60,
	"SETENTA": 70,
	"OCHENTA": 80,
	"NOVENTA": 90,
}

# Correcciones mínimas de ruido OCR en palabras de día (1..31).
_OCR_DAY_TOKEN_FIXES: dict[str, str] = {
	"VEINTDOS": "VEINTIDOS",
	"VEINTI DOS": "VEINTIDOS",
}

# Patrón frecuente: ... LOS [DIAS DEL ]?VEINTIDOS DEL ANO DOS MIL MES DE ENERO (texto ya en mayúsculas sin acentos).
_FECHA_CONVEGAN_DOS_MIL_MES = re.compile(
	r"LOS(?:\s+DIAS?\s+DEL)?\s+(?P<dw>[A-Z0-9]+)\s+DEL\s+ANO\s+DOS\s+MIL\s+MES\s+DE\s+(?P<mon>[A-Z]+)",
	re.IGNORECASE,
)


def _certificado_reference_year() -> int:
	"""Año de referencia para constancias actuales (p. ej. DOS MIL sin cola). Extensible en tests."""
	return datetime.date.today().year


def _norm_text(s: str) -> str:
	return s.replace("\r\n", "\n").replace("\r", "\n")


def _upper_no_accents(s: str) -> str:
	n = unicodedata.normalize("NFD", s)
	return "".join(ch for ch in n if unicodedata.category(ch) != "Mn").upper()


def _lines(s: str) -> List[str]:
	return [ln.strip() for ln in _norm_text(s).split("\n")]


def _next_non_empty(lines: List[str], idx: int, max_ahead: int = 6) -> str | None:
	for j in range(idx + 1, min(len(lines), idx + 1 + max_ahead)):
		if lines[j]:
			return lines[j].strip(" :,-.")
	return None


def _extract_nombre(lines: List[str]) -> tuple[str | None, float]:
	for i, ln in enumerate(lines):
		if ANCHOR_NOMBRE.search(_upper_no_accents(ln)):
			nm = _next_non_empty(lines, i)
			if nm and len(nm) > 3:
				return nm, 0.9
	return None, 0.0


def _extract_direccion(lines: List[str]) -> tuple[str | None, float]:
	for i, ln in enumerate(lines):
		current = _upper_no_accents(ln)
		next_ln = _upper_no_accents(lines[i + 1]) if i + 1 < len(lines) else ""
		combined = f"{current} {next_ln}".strip()
		on_line = bool(ANCHOR_DIRECCION.search(current))
		on_pair = bool(ANCHOR_DIRECCION.search(combined))
		split_c = current == "C." and ("ANOS DE EDAD" in next_ln or "AÑOS DE EDAD" in next_ln)
		if not (on_line or on_pair or split_c):
			continue
		if split_c:
			start_idx = i + 1
		elif on_line:
			start_idx = i
		else:
			start_idx = i + 1
		parts: list[str] = []
		for j in range(start_idx + 1, min(start_idx + 7, len(lines))):
			raw = lines[j].strip(" :,-.")
			if not raw:
				continue
			if STOP_DIRECCION.search(_upper_no_accents(raw)):
				break
			parts.append(raw)
		if parts:
			return ", ".join(parts), 0.86
	return None, 0.0


def _resolve_day_word_token(raw: str) -> int | None:
	"""Un token de día en palabras (p. ej. VEINTIDOS, VEINTDOS OCR)."""
	t = _upper_no_accents(raw.strip())
	t = _OCR_DAY_TOKEN_FIXES.get(t, t)
	if t in SPECIALS:
		v = SPECIALS[t]
		if 1 <= v <= 31:
			return v
	if t in UNITS:
		v = UNITS[t]
		if 1 <= v <= 31:
			return v
	return _parse_spanish_number(t.split())


def _parse_spanish_number(tokens: List[str]) -> int | None:
	if not tokens:
		return None
	if len(tokens) == 1:
		t = tokens[0]
		if t in SPECIALS:
			return SPECIALS[t]
		if t in UNITS:
			return UNITS[t]
		if t in TENS:
			return TENS[t]
		return None
	if len(tokens) == 2 and tokens[0] in TENS and tokens[1] in UNITS:
		return TENS[tokens[0]] + UNITS[tokens[1]]
	if len(tokens) == 4 and tokens[0] == "DOS" and tokens[1] == "MIL":
		n = _parse_spanish_number(tokens[2:])
		return 2000 + n if n is not None else 2000
	if len(tokens) == 2 and tokens[0] == "DOS" and tokens[1] == "MIL":
		return 2000
	return None


def _extract_fecha(lines: List[str], text: str) -> tuple[str | None, float]:
	# Fallback rápido para fecha digital.
	m = FECHA_DIGITAL_PATTERN.search(text)
	if m:
		return m.group(1), 0.9

	up_lines = [_upper_no_accents(ln) for ln in lines]
	start = -1
	for i, ln in enumerate(up_lines):
		if ANCHOR_FECHA.search(ln):
			start = i
			break
	if start < 0:
		return None, 0.0

	window = [ln for ln in up_lines[start : min(start + 10, len(up_lines))] if ln]
	window_text = " ".join(window)
	# Texto plano en mayúsculas sin acentos para regex (ANO, MES, etc.).
	wt = _upper_no_accents(window_text)

	day = None
	month = None
	year = None

	# Patrón constancia: día en palabras + DOS MIL + MES DE <mes> (año actual si no hay cola numérica).
	m_cruz = _FECHA_CONVEGAN_DOS_MIL_MES.search(wt)
	if m_cruz:
		dw = m_cruz.group("dw").upper()
		mon_tok = m_cruz.group("mon").upper()
		if mon_tok in MONTHS:
			day = _resolve_day_word_token(dw)
			month = MONTHS[mon_tok]
			if day is not None and month:
				year = _certificado_reference_year()
				return f"{day:02d}/{month:02d}/{year:04d}", 0.84

	for token in window:
		if token in MONTHS:
			month = MONTHS[token]
			break

	# Día: primera palabra numérica en ventana antes de "MES DE".
	for token in window:
		if token in {"DIAS DEL", "DIA DEL", "MES DE", "DEL ANO", "DEL AÑO"}:
			continue
		candidate = _resolve_day_word_token(token)
		if candidate is None:
			candidate = _parse_spanish_number(token.split())
		if candidate is not None and 1 <= candidate <= 31:
			day = candidate
			break

	# Año: buscar secuencia "DOS MIL <...>" o número de 4 dígitos.
	tail: int | None = None
	m4 = re.search(r"\b(19\d{2}|20\d{2})\b", window_text)
	if m4:
		year = int(m4.group(1))
	else:
		number_lines: list[int] = []
		for token in window:
			v = _parse_spanish_number(token.split())
			if v is not None:
				number_lines.append(v)
		if "DOS MIL" in window_text:
			tail = next((v for v in number_lines if 0 <= v <= 99 and v != day), None)
			if tail is not None:
				year = 2000 + tail
			else:
				# Constancias recientes: sin cola explícita tras DOS MIL, usar año calendario actual.
				year = _certificado_reference_year()

	if day and month and year:
		conf = 0.88
		if (
			not m4
			and "DOS MIL" in window_text
			and tail is None
			and year == _certificado_reference_year()
		):
			conf = 0.8
		return f"{day:02d}/{month:02d}/{year:04d}", conf

	# Fallback: devolver texto reconstruido de lo que sí se intentó.
	return " ".join(lines[start : min(start + 8, len(lines))]).strip(), 0.55


class CertificadoMedicoExtractor(BaseExtractor):
	def empty_fields(self) -> Dict[str, Any]:
		return {
			"nombre_alumno": self._field_null(),
			"direccion": self._field_null(),
			"fecha_expedicion": self._field_null(),
		}

	def extract_with_coords(
		self,
		text: str,
		lines: list[dict[str, Any]] | None = None,
		words: list[dict[str, Any]] | None = None,
	) -> Dict[str, Any]:
		_ = words
		if not lines:
			return self.extract(text)
		nombre_alumno = None
		nombre_conf = 0.0
		direccion = None
		direccion_conf = 0.0
		fecha_expedicion = None
		fecha_conf = 0.0
		nom_anchor = find_line_anchor(lines, [r"POR\s+ESTE\s+MEDIO\s+SE\s+DIRIGE\s+A\s+USTED"])
		if nom_anchor:
			ln = line_below_anchor(lines, nom_anchor, min_dy=8, max_dy=55)
			if ln:
				nombre_alumno = ln.get("text", "").strip()
				nombre_conf = 0.9
		dir_anchor = find_line_anchor(lines, [r"DOMICILIO\s+EN", r"A[NÑ]OS\s+DE\s+EDAD\s+CON"])
		if dir_anchor:
			base_top = int(dir_anchor.get("top", 0))
			dir_lines = [
				ln.get("text", "").strip()
				for ln in lines
				if int(ln.get("top", 0)) >= base_top - 5
				and int(ln.get("top", 0)) <= base_top + 90
				and re.search(r"C\.|CALLE|COL|HIDALGO|SANTIAGO|LT|LTE|JOYA", ln.get("text", ""), re.I)
			]
			if dir_lines:
				direccion = ", ".join(dir_lines[:3])
				direccion_conf = 0.86
		fecha_anchor = find_line_anchor(lines, [r"CONVENGAN\s+A\s+LOS"])
		if fecha_anchor:
			block = [
				ln.get("text", "").strip()
				for ln in lines
				if int(ln.get("top", 0)) >= int(fecha_anchor.get("top", 0))
				and int(ln.get("top", 0)) <= int(fecha_anchor.get("top", 0)) + 80
			]
			t = " ".join(block)
			digital = FECHA_DIGITAL_PATTERN.search(t)
			if digital:
				fecha_expedicion = digital.group(1).replace("-", "/")
				fecha_conf = 0.9
			else:
				fval, fconf = _extract_fecha(_lines(t), t)
				fecha_expedicion = fval
				fecha_conf = fconf
		fallback = self.extract(text)
		if not nombre_alumno:
			nombre_alumno = fallback["nombre_alumno"]["value"]
			nombre_conf = fallback["nombre_alumno"]["confidence"]
		if not direccion:
			direccion = fallback["direccion"]["value"]
			direccion_conf = fallback["direccion"]["confidence"]
		if not fecha_expedicion:
			fecha_expedicion = fallback["fecha_expedicion"]["value"]
			fecha_conf = fallback["fecha_expedicion"]["confidence"]
		return {
			"nombre_alumno": {"value": nombre_alumno, "confidence": nombre_conf},
			"direccion": {"value": direccion, "confidence": direccion_conf},
			"fecha_expedicion": {"value": fecha_expedicion, "confidence": fecha_conf},
		}

	def extract(self, text: str) -> Dict[str, Any]:
		lines = _lines(text)

		nombre_alumno, nombre_conf = _extract_nombre(lines)
		if not nombre_alumno:
			n, c = pick_title_name(text)
			if n and not _CERT_NAME_BLACKLIST.search(n):
				nombre_alumno, nombre_conf = n, max(nombre_conf, c)
			else:
				n, c = pick_allcaps_name(text, 0.55)
				if n and not _CERT_NAME_BLACKLIST.search(n):
					nombre_alumno, nombre_conf = n, max(nombre_conf, c)

		direccion, direccion_conf = _extract_direccion(lines)
		fecha_expedicion, fecha_conf = _extract_fecha(lines, text)

		return {
			"nombre_alumno": {"value": nombre_alumno, "confidence": nombre_conf},
			"direccion": {"value": direccion, "confidence": direccion_conf},
			"fecha_expedicion": {"value": fecha_expedicion, "confidence": fecha_conf},
		}
