# config.py
import os
from pathlib import Path

# Rutas base
BASE_DIR = Path(__file__).parent.resolve()

# Límites
MAX_FILE_SIZE = 20 * 1024 * 1024  # 20 MB
SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tiff", ".bmp"}

# Configuración de OCR por defecto
DEFAULT_LANG = "spa"
DEFAULT_PSM = 6
DEFAULT_OEM = 3


def _int_from_env(name: str, default: int) -> int:
	try:
		return int(os.environ.get(name, str(default)))
	except ValueError:
		return default


def _bool_from_env(name: str, default: bool) -> bool:
	val = os.environ.get(name)
	if val is None:
		return default
	return val.strip().lower() in ("1", "true", "yes", "on")


def _float_from_env(name: str, default: float) -> float:
	try:
		return float(os.environ.get(name, str(default)))
	except ValueError:
		return default


# Timeout OCR.space (segundos). Debe permitir SLA end-to-end <= 10s.
OCR_SPACE_TIMEOUT = _int_from_env("OCR_SPACE_TIMEOUT", 5)

# Tamaño máximo de payload para OCR.space (bytes). Se usa reducción automática si se supera.
OCR_SPACE_MAX_UPLOAD_BYTES = _int_from_env("OCR_SPACE_MAX_UPLOAD_BYTES", 950000)

# Lado mayor al decodificar imagen en /ocr/extract (sin re-compresión por MB si compress=False).
# Default 4096 alineado con OCR_PREPARE_READ_MAX_DIM (balance RAM / detalle).
OCR_EXTRACT_READ_MAX_DIM = _int_from_env("OCR_EXTRACT_READ_MAX_DIM", 4096)
# 0 o negativo = sin downscale antes del envío a OCR.space.
OCR_EXTRACT_DOWNSCALE_MAX_SIDE = _int_from_env("OCR_EXTRACT_DOWNSCALE_MAX_SIDE", 0)

# Por encima de este número de píxeles, preprocess_light usa denoise bilateral en lugar de nlmeans.
OCR_NLMEANS_MAX_PIXELS = _int_from_env("OCR_NLMEANS_MAX_PIXELS", 700000)

# Lado mayor al decodificar imagen en /ocr/prepare (sin re-compresión JPEG por MB; techo ante imágenes enormes).
OCR_PREPARE_READ_MAX_DIM = _int_from_env("OCR_PREPARE_READ_MAX_DIM", 4096)

# Calidad JPEG de salida en /ocr/prepare (1–100).
def _jpeg_quality_from_env(name: str, default: int) -> int:
	q = _int_from_env(name, default)
	return max(1, min(100, q))


OCR_PREPARE_JPEG_QUALITY = _jpeg_quality_from_env("OCR_PREPARE_JPEG_QUALITY", 100)

# Límites para `lado_max_lectura` en multipart de /ocr/prepare (petición).
OCR_PREPARE_READ_MAX_DIM_CAP = _int_from_env("OCR_PREPARE_READ_MAX_DIM_CAP", 4096)
OCR_PREPARE_READ_MIN_DIM = _int_from_env("OCR_PREPARE_READ_MIN_DIM", 256)
# Si False, se ignoran calidad_jpeg y lado_max_lectura del formulario (solo config/env).
OCR_PREPARE_ALLOW_REQUEST_TUNING = _bool_from_env("OCR_PREPARE_ALLOW_REQUEST_TUNING", False)

# Saturación HSV en preprocess_light / prepare: por defecto activa (petición mínima sin flags).
OCR_APPLY_HSV_SATURATION = _bool_from_env("OCR_APPLY_HSV_SATURATION", True)

# En /ocr/prepare: por defecto AIDA preserva imagen sin binarizar; este env permite compatibilidad en despliegues legados.
PREPARE_DEFAULT_BINARIZAR = _bool_from_env("PREPARE_DEFAULT_BINARIZAR", False)

# Si true, tras HSV (si aplica) se aplica CLAHE suave (apply_clahe_prepare) antes del JPEG.
# Default false: contrato mínimo sin contraste adaptativo en prepare; activar solo tras pruebas en staging.
OCR_PREPARE_SOFT_CLAHE = _bool_from_env("OCR_PREPARE_SOFT_CLAHE", False)

# Modo opcional de mejora fotométrica en /ocr/prepare (solo si cliente lo solicita).
OCR_PREPARE_ENABLE_AUTO_ENHANCE = _bool_from_env("OCR_PREPARE_ENABLE_AUTO_ENHANCE", False)
OCR_PREPARE_ENHANCE_ENGINE_DEFAULT = os.environ.get(
	"OCR_PREPARE_ENHANCE_ENGINE_DEFAULT", "opencv"
).strip().lower()
OCR_PREPARE_ENHANCE_TIMEOUT_SECONDS = _int_from_env("OCR_PREPARE_ENHANCE_TIMEOUT_SECONDS", 2)

# Si true, image_enhancer usa presets por bucket de luminancia (clasificación OpenCV previa).
OCR_PREPARE_IMAGE_ENHANCER_LUMA_PRESETS = _bool_from_env(
	"OCR_PREPARE_IMAGE_ENHANCER_LUMA_PRESETS", True
)

# Cabeceras extra de diagnóstico en /ocr/prepare (luma/bucket/preset). Solo staging recomendado.
OCR_PREPARE_DIAGNOSTIC_HEADERS = _bool_from_env("OCR_PREPARE_DIAGNOSTIC_HEADERS", False)

# Umbrales del comparador modo simple escuela (/ocr/prepare). Solo eligen fila de preset;
# no son parámetros de tratamiento (calibrar con fotos reales de escuela).
OCR_PREPARE_SCHOOL_MEAN_GRAY_BAD_MAX = _float_from_env(
	"OCR_PREPARE_SCHOOL_MEAN_GRAY_BAD_MAX", 118.0
)
OCR_PREPARE_SCHOOL_WARM_RB_DELTA = _float_from_env(
	"OCR_PREPARE_SCHOOL_WARM_RB_DELTA", 24.0
)

# En /ocr/extract: preproceso visual (CLAHE/sombras/denoise). Default false: OCR.space suele ir mejor sin preprocess_light.
# Activar con env true o multipart aplicar_preproceso_ocr=true.
OCR_EXTRACT_APPLY_PREPROCESS = _bool_from_env("OCR_EXTRACT_APPLY_PREPROCESS", False)

# Concurrencia: máximo de peticiones /ocr/prepare y /ocr/extract en vuelo (espera en cola si está lleno). 0 = sin límite.
OCR_MAX_CONCURRENT_REQUESTS = _int_from_env("OCR_MAX_CONCURRENT_REQUESTS", 10)

# Rate limit por IP (memoria por instancia). 0 = desactivado.
OCR_RATE_LIMIT_REQUESTS = _int_from_env("OCR_RATE_LIMIT_REQUESTS", 30)
OCR_RATE_LIMIT_WINDOW_SECONDS = _int_from_env("OCR_RATE_LIMIT_WINDOW_SECONDS", 600)
