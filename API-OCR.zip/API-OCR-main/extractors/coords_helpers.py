from __future__ import annotations

import re
import unicodedata
from typing import Any, Dict, List, Optional


def normalize_simple(text: str) -> str:
	n = unicodedata.normalize("NFD", text or "")
	no_acc = "".join(ch for ch in n if unicodedata.category(ch) != "Mn")
	return re.sub(r"\s+", " ", no_acc).strip().upper()


def normalize_lines(text: str) -> List[str]:
	return [ln.strip() for ln in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")]


def build_overlay_lines(words: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
	"""
	Agrupa palabras por cercanía vertical para reconstruir líneas cuando sea necesario.
	"""
	if not words:
		return []
	sorted_words = sorted(
		words,
		key=lambda w: (int(w.get("top", 0)), int(w.get("left", 0))),
	)
	lines: List[List[Dict[str, Any]]] = []
	for w in sorted_words:
		top = int(w.get("top", 0))
		if not lines:
			lines.append([w])
			continue
		prev_top = int(lines[-1][0].get("top", 0))
		if abs(top - prev_top) <= 14:
			lines[-1].append(w)
		else:
			lines.append([w])
	out: List[Dict[str, Any]] = []
	for idx, group in enumerate(lines):
		group_sorted = sorted(group, key=lambda x: int(x.get("left", 0)))
		text = " ".join((g.get("text") or "").strip() for g in group_sorted).strip()
		if not text:
			continue
		min_left = min(int(g.get("left", 0)) for g in group_sorted)
		min_top = min(int(g.get("top", 0)) for g in group_sorted)
		max_right = max(int(g.get("left", 0)) + int(g.get("width", 0)) for g in group_sorted)
		max_bottom = max(int(g.get("top", 0)) + int(g.get("height", 0)) for g in group_sorted)
		out.append(
			{
				"idx": idx,
				"text": text,
				"left": min_left,
				"top": min_top,
				"width": max_right - min_left,
				"height": max_bottom - min_top,
			}
		)
	return out


def find_line_anchor(
	lines: List[Dict[str, Any]],
	patterns: List[str],
) -> Optional[Dict[str, Any]]:
	if not lines:
		return None
	regexes = [re.compile(p, re.I) for p in patterns]
	for ln in lines:
		txt = normalize_simple(ln.get("text", ""))
		for rx in regexes:
			if rx.search(txt):
				return ln
	return None


def line_below_anchor(
	lines: List[Dict[str, Any]],
	anchor: Dict[str, Any],
	min_dy: int = 6,
	max_dy: int = 65,
) -> Optional[Dict[str, Any]]:
	a_top = int(anchor.get("top", 0))
	a_left = int(anchor.get("left", 0))
	candidates: List[Dict[str, Any]] = []
	for ln in lines:
		dy = int(ln.get("top", 0)) - a_top
		if dy < min_dy or dy > max_dy:
			continue
		if abs(int(ln.get("left", 0)) - a_left) > 260:
			continue
		candidates.append(ln)
	if not candidates:
		return None
	candidates.sort(key=lambda x: int(x.get("top", 0)))
	return candidates[0]


def first_regex_in_lines(lines: List[Dict[str, Any]], pattern: re.Pattern[str]) -> Optional[str]:
	for ln in lines:
		m = pattern.search(ln.get("text", ""))
		if m:
			return m.group(1) if m.groups() else m.group(0)
	return None
