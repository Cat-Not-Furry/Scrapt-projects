from .ocr_space import OCRSpaceResult, ocr_space_extract

__all__ = ["OCRSpaceResult", "ocr_space_extract"]
