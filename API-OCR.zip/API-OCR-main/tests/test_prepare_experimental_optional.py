"""Tests sintéticos para balance de blancos y desaturación selectiva (stack experimental /ocr/prepare)."""

import pytest

pytest.importorskip("cv2")
import cv2
import numpy as np

from preprocessing.enhance import desaturate_selective_rgb, white_balance_simple_rgb


def _orange_tint_rgb() -> np.ndarray:
	img = np.zeros((64, 64, 3), dtype=np.uint8)
	img[:, :, 0] = 220
	img[:, :, 1] = 140
	img[:, :, 2] = 80
	return img


def test_white_balance_reduces_channel_spread() -> None:
	img = _orange_tint_rgb()
	out = white_balance_simple_rgb(img, 1.0)
	mr0, mg0, mb0 = (
		float(np.mean(img[:, :, 0])),
		float(np.mean(img[:, :, 1])),
		float(np.mean(img[:, :, 2])),
	)
	mr1, mg1, mb1 = (
		float(np.mean(out[:, :, 0])),
		float(np.mean(out[:, :, 1])),
		float(np.mean(out[:, :, 2])),
	)
	spread_before = max(mr0, mg0, mb0) - min(mr0, mg0, mb0)
	spread_after = max(mr1, mg1, mb1) - min(mr1, mg1, mb1)
	assert spread_after < spread_before * 0.85


def test_desaturate_selective_reduces_high_saturation() -> None:
	img = np.zeros((64, 64, 3), dtype=np.uint8)
	img[:, :] = (255, 0, 0)
	hsv_in = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
	s_in_max = float(np.max(hsv_in[:, :, 1]))
	out = desaturate_selective_rgb(img, 0.85, sat_threshold=None)
	hsv_out = cv2.cvtColor(out, cv2.COLOR_RGB2HSV)
	s_out_max = float(np.max(hsv_out[:, :, 1]))
	assert s_out_max < s_in_max - 15.0
