# tests/test_certificado_medico_fecha.py
"""Fechas en palabras para constancia tipo Cruz Roja."""

from unittest.mock import patch

from extractors.certificado_medico import _extract_fecha, _lines


def _fecha(text: str):
	lines = _lines(text)
	return _extract_fecha(lines, text)


def test_fecha_convegan_veintidos_dos_mil_mes_enero():
	text = "(A). CONVENGAN A LOS VEINTIDOS DEL AÑO DOS MIL MES DE ENERO"
	with patch("extractors.certificado_medico._certificado_reference_year", return_value=2026):
		val, conf = _fecha(text)
	assert val == "22/01/2026"
	assert conf >= 0.8


def test_fecha_dias_del_veintdos_ocr():
	text = "CONVENGAN A LOS DIAS DEL VEINTDOS DEL AÑO DOS MIL MES DE ENERO"
	with patch("extractors.certificado_medico._certificado_reference_year", return_value=2026):
		val, conf = _fecha(text)
	assert val == "22/01/2026"
	assert conf >= 0.8


def test_fecha_digital_sin_cambio():
	text = "Texto CONVENGAN A LOS 15/03/2024 y más"
	val, conf = _fecha(text)
	assert val == "15/03/2024"
	assert conf >= 0.85


def test_dos_mil_sin_cola_usa_anio_actual():
	text = (
		"Línea previa\n"
		"CONVENGAN A LOS QUINCE DEL AÑO DOS MIL\n"
		"MES DE MARZO\n"
	)
	with patch("extractors.certificado_medico._certificado_reference_year", return_value=2025):
		val, conf = _fecha(text)
	assert val == "15/03/2025"
	assert conf >= 0.8
