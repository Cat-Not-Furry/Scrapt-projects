# main.py
import asyncio
import gc
import logging
import os
import tempfile
import time
import re
from pathlib import Path
from typing import Optional

import cv2
import uvicorn
from fastapi import BackgroundTasks, Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from config import (
	DEFAULT_LANG,
	OCR_APPLY_HSV_SATURATION,
	OCR_EXTRACT_APPLY_PREPROCESS,
	OCR_EXTRACT_DOWNSCALE_MAX_SIDE,
	OCR_EXTRACT_READ_MAX_DIM,
	OCR_PREPARE_ALLOW_REQUEST_TUNING,
	OCR_PREPARE_DIAGNOSTIC_HEADERS,
	OCR_PREPARE_ENABLE_AUTO_ENHANCE,
	OCR_PREPARE_ENHANCE_ENGINE_DEFAULT,
	OCR_PREPARE_ENHANCE_TIMEOUT_SECONDS,
	OCR_PREPARE_IMAGE_ENHANCER_LUMA_PRESETS,
	OCR_PREPARE_JPEG_QUALITY,
	OCR_PREPARE_READ_MAX_DIM,
	OCR_PREPARE_READ_MAX_DIM_CAP,
	OCR_PREPARE_READ_MIN_DIM,
	OCR_PREPARE_SOFT_CLAHE,
	PREPARE_DEFAULT_BINARIZAR,
)
from extractors import (
	ActaExtractor,
	CertificadoMedicoExtractor,
	ComprobanteExtractor,
	CURPExtractor,
	INEExtractor,
)
from integration.ocr_space import OCRSpaceResult, ocr_space_extract
from preprocessing.enhance import (
	PrepareLumaClassification,
	apply_clahe_prepare,
	apply_prepare_experimental_stack,
	classify_prepare_luma,
	enhance_photometric_image_enhancer,
	enhance_photometric_opencv,
	image_enhancer_params_for_bucket,
	IMAGE_ENHANCER_PARAMS_LEGACY,
	apply_hs_saturation_scale_rgb,
	downscale_max_side,
	opencv_enhance_preset_id,
	preprocess_light,
)
from preprocessing.prepare_school_presets import (
	SCHOOL_PREPARE_PRESETS,
	classify_school_lighting,
	is_server_default_prepare_bundle,
)
from preprocessing.quality import compute_white_distance_metrics
from utils.file_handling import read_image, validate_file
from utils.logging_config import setup_logging
from utils.ocr_limits import ocr_concurrency_dep, ocr_rate_limit_dep

setup_logging()
logger = logging.getLogger(__name__)

EXTRACT_READ_MAX_MB = 1.0
# En prepare, amortigua s_mult respecto a métricas cuando HSV está solicitado (sellos/tinta clara).
_PREPARE_HSV_SATURATION_DAMPEN = 0.65

_PREPARE_CONTRACT_MSG = (
	"/ocr/prepare solo admite preservación mínima: modo=auto, sin corregir_perspectiva, "
	"sin corregir_inclinacion, sin binarizar, sin fuerza_mejora. "
	"Opcional: aplicar_saturacion_hsv o variable OCR_APPLY_HSV_SATURATION."
)


def _want_hsv_saturation(form_aplicar: Optional[bool]) -> bool:
	if form_aplicar is not None:
		return form_aplicar
	return bool(OCR_APPLY_HSV_SATURATION)


_PREPARE_GAMMA_MIN = 0.05
_PREPARE_GAMMA_MAX = 5.0


def _validate_preparar_experimental_multipart(
	preparar_nitidez: float,
	preparar_saturacion: float,
	preparar_gamma_valor: float,
	preparar_balance_blancos: bool,
	preparar_balance_intensidad: float,
	preparar_corregir_iluminacion: bool,
	preparar_iluminacion_intensidad: float,
	preparar_desaturacion_selectiva: bool,
	preparar_desaturacion_fuerza: float,
) -> None:
	if (
		preparar_gamma_valor < _PREPARE_GAMMA_MIN
		or preparar_gamma_valor > _PREPARE_GAMMA_MAX
	):
		raise HTTPException(
			status_code=400,
			detail=(
				f"preparar_gamma_valor debe estar entre {_PREPARE_GAMMA_MIN} y {_PREPARE_GAMMA_MAX} "
				f"(recibido {preparar_gamma_valor})."
			),
		)
	if preparar_nitidez < 0.0 or preparar_nitidez > 2.0:
		raise HTTPException(
			status_code=400,
			detail=f"preparar_nitidez debe estar entre 0 y 2.0 (recibido {preparar_nitidez}).",
		)
	if preparar_saturacion < 0.0 or preparar_saturacion > 3.0:
		raise HTTPException(
			status_code=400,
			detail=f"preparar_saturacion debe estar entre 0 y 3.0 (recibido {preparar_saturacion}).",
		)
	if preparar_balance_blancos:
		if preparar_balance_intensidad < 0.0 or preparar_balance_intensidad > 1.0:
			raise HTTPException(
				status_code=400,
				detail=(
					"preparar_balance_intensidad debe estar entre 0 y 1 "
					f"(recibido {preparar_balance_intensidad})."
				),
			)
	if preparar_corregir_iluminacion:
		if preparar_iluminacion_intensidad < 0.0 or preparar_iluminacion_intensidad > 1.0:
			raise HTTPException(
				status_code=400,
				detail=(
					"preparar_iluminacion_intensidad debe estar entre 0 y 1 "
					f"(recibido {preparar_iluminacion_intensidad})."
				),
			)
	if preparar_desaturacion_selectiva:
		if preparar_desaturacion_fuerza < 0.0 or preparar_desaturacion_fuerza > 1.0:
			raise HTTPException(
				status_code=400,
				detail=(
					"preparar_desaturacion_fuerza debe estar entre 0 y 1 "
					f"(recibido {preparar_desaturacion_fuerza})."
				),
			)


def _want_extract_preprocess(form_aplicar: Optional[bool]) -> bool:
	if form_aplicar is not None:
		return form_aplicar
	return bool(OCR_EXTRACT_APPLY_PREPROCESS)


def _prepare_reject_legacy_params(
	modo_norm: str,
	corregir_perspectiva: bool,
	corregir_inclinacion: bool,
	binarizar: bool,
	fuerza_mejora: Optional[float],
) -> None:
	if modo_norm != "auto":
		raise HTTPException(
			status_code=400,
			detail=f"{_PREPARE_CONTRACT_MSG} Enviaste modo distinto de auto.",
		)
	if corregir_perspectiva:
		raise HTTPException(
			status_code=400,
			detail=f"{_PREPARE_CONTRACT_MSG} corregir_perspectiva no está soportado.",
		)
	if corregir_inclinacion:
		raise HTTPException(
			status_code=400,
			detail=f"{_PREPARE_CONTRACT_MSG} corregir_inclinacion no está soportado.",
		)
	if binarizar:
		raise HTTPException(
			status_code=400,
			detail=f"{_PREPARE_CONTRACT_MSG} binarizar no está soportado. "
			"Si PREPARE_DEFAULT_BINARIZAR=true en el servidor, desactívalo en despliegue AIDA.",
		)
	if fuerza_mejora is not None:
		raise HTTPException(
			status_code=400,
			detail=f"{_PREPARE_CONTRACT_MSG} fuerza_mejora no está soportado.",
		)


_OCR_ROUTE_DEPS = [Depends(ocr_rate_limit_dep), Depends(ocr_concurrency_dep)]

EXTRACTORS = {
	"acta_nacimiento": ActaExtractor(),
	"curp": CURPExtractor(),
	"ine": INEExtractor(),
	"comprobante": ComprobanteExtractor(),
	"certificado_medico": CertificadoMedicoExtractor(),
}


_DATE_DMY = re.compile(r"^\s*(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\s*$")
_DATE_YMD = re.compile(r"^\s*(\d{4})[/-](\d{1,2})[/-](\d{1,2})\s*$")


def _normalize_date_value(value: Optional[str]) -> Optional[str]:
	if not value:
		return value
	m = _DATE_DMY.match(value)
	if m:
		d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
		if y < 100:
			y = 2000 + y
		return f"{d:02d}/{mo:02d}/{y:04d}"
	m = _DATE_YMD.match(value)
	if m:
		y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
		return f"{d:02d}/{mo:02d}/{y:04d}"
	return value


def _normalize_output_dates(fields: dict) -> dict:
	for key, val in fields.items():
		if not isinstance(val, dict):
			continue
		if "value" not in val:
			continue
		if "fecha" in key.lower():
			val["value"] = _normalize_date_value(val.get("value"))
	return fields


app = FastAPI(
	title="OCR AIDA Pro",
	description=(
		"API mínima: extracción de metadatos y preparación de imagen. "
		"Integración mínima AIDA (multipart: solo file en /ocr/prepare; file y tramite en /ocr/extract): "
		"ver README, sección «Integración mínima AIDA (plug-and-play)». "
		"Manual y ejemplos en texto plano: docs/OCR_AIDA_MANUAL_OPERACION.txt y docs/OCR_AIDA_EJEMPLOS_Y_FORMATOS.txt."
	),
)

app.add_middleware(
	CORSMiddleware,
	allow_origins=["*"],
	allow_credentials=True,
	allow_methods=["*"],
	allow_headers=["*"],
)


@app.get("/")
async def root():
	return {
		"message": "API OCR AIDA Pro",
		"status": "ok",
		"endpoints": ["/health", "/ocr/extract", "/ocr/prepare"],
		"ocr_engine": "ocr_space",
	}


@app.get("/health")
async def health():
	return {
		"status": "ok",
		"message": "API OCR AIDA Pro",
		"ocr_engine": "ocr_space",
	}


@app.post("/ocr/extract", dependencies=_OCR_ROUTE_DEPS)
async def extract_metadata(
	file: UploadFile = File(...),
	tramite: str = Form(...),
	lang: str = Form(DEFAULT_LANG),
	use_ocr_space_fallback: bool = Form(True),
	aplicar_saturacion_hsv: Optional[bool] = Form(None),
	aplicar_preproceso_ocr: Optional[bool] = Form(None),
):
	start = time.time()
	original_size = 0
	compressed_size = 0
	tmp_path = None
	ocr_source = "ocr_space"
	img = None
	processed = None
	ocr_ok = False
	request_id = f"ocr-{int(time.time() * 1000)}"
	try:
		validate_file(file)
		if tramite not in EXTRACTORS:
			raise HTTPException(
				status_code=400,
				detail=f"tramite inválido. Opciones: {', '.join(EXTRACTORS.keys())}",
			)

		img, original_size = await read_image(
			file,
			compress=False,
			max_size_mb=EXTRACT_READ_MAX_MB,
			max_dimension=OCR_EXTRACT_READ_MAX_DIM,
		)
		_, buf = cv2.imencode(".jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
		compressed_size = len(buf)

		want_hsv = _want_hsv_saturation(aplicar_saturacion_hsv)
		want_preprocess = _want_extract_preprocess(aplicar_preproceso_ocr)
		t_pre = time.time()
		if want_preprocess:
			processed = preprocess_light(img.copy(), apply_hs_saturation=want_hsv)
		else:
			processed = img.copy()
		pre_ms = round((time.time() - t_pre) * 1000, 1)
		h0, w0 = processed.shape[:2]
		down_max = OCR_EXTRACT_DOWNSCALE_MAX_SIDE
		processed = downscale_max_side(processed, down_max)
		h1, w1 = processed.shape[:2]
		logger.info(
			"/ocr/extract request_id=%s stage=preprocess mode=%s %.1fms shape %dx%d -> %dx%d (downscale_max_side=%d)",
			request_id,
			"preprocess_light" if want_preprocess else "preservacion",
			pre_ms,
			w0,
			h0,
			w1,
			h1,
			down_max,
		)

		with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
			tmp_path = tmp.name

		if len(processed.shape) == 2:
			cv2.imwrite(tmp_path, processed)
		else:
			cv2.imwrite(tmp_path, cv2.cvtColor(processed, cv2.COLOR_RGB2BGR))
		if not use_ocr_space_fallback:
			logger.info(
				"/ocr/extract request_id=%s stage=ocr_space_call ocr desactivado por formulario",
				request_id,
			)
		ocr_res: OCRSpaceResult = await asyncio.to_thread(ocr_space_extract, tmp_path, lang)
		if ocr_res.ok:
			ocr_ok = True
			extractor = EXTRACTORS[tramite]
			fields = extractor.extract_with_coords(
				ocr_res.text,
				lines=ocr_res.lines,
				words=ocr_res.words,
			)
		else:
			extractor = EXTRACTORS[tramite]
			fields = extractor.empty_fields()
			logger.error(
				"/ocr/extract request_id=%s stage=%s tramite=%s ocr_fail=%s ocr_exit_code=%s",
				request_id,
				ocr_res.error_stage,
				tramite,
				ocr_res.error_detail,
				ocr_res.ocr_exit_code,
			)
		fields = _normalize_output_dates(fields)
		duration = round(time.time() - start, 2)
		logger.info(
			"/ocr/extract request_id=%s stage=extractor_done tramite=%s ocr_ok=%s elapsed_ms=%d original_size=%d compressed_size=%d",
			request_id,
			tramite,
			ocr_ok,
			int(duration * 1000),
			original_size,
			compressed_size,
		)

		return {
			"success": True,
			"tramite": tramite,
			"fields": fields,
			"metadata": {
				"language": lang,
				"ocr_source": ocr_source,
				"ocr_ok": ocr_ok,
				"processing_time": duration,
				"original_size": original_size,
				"compressed_size": compressed_size,
			},
		}
	finally:
		if tmp_path and os.path.exists(tmp_path):
			try:
				os.unlink(tmp_path)
			except OSError:
				pass
		img = None
		processed = None
		gc.collect()


@app.post("/ocr/prepare", dependencies=_OCR_ROUTE_DEPS)
async def prepare_image(
	background_tasks: BackgroundTasks,
	file: UploadFile = File(...),
	corregir_perspectiva: bool = Form(False),
	corregir_inclinacion: bool = Form(False),
	binarizar: bool = Form(PREPARE_DEFAULT_BINARIZAR),
	modo: str = Form("auto"),
	fuerza_mejora: Optional[float] = Form(None),
	aplicar_saturacion_hsv: Optional[bool] = Form(None),
	auto_enhance: bool = Form(False),
	enhance_engine: Optional[str] = Form(None),
	calidad_jpeg: Optional[int] = Form(None),
	lado_max_lectura: Optional[int] = Form(None),
	preparar_balance_blancos: bool = Form(False),
	preparar_balance_intensidad: float = Form(0.35),
	preparar_corregir_iluminacion: bool = Form(False),
	preparar_iluminacion_intensidad: float = Form(0.5),
	preparar_desaturacion_selectiva: bool = Form(False),
	preparar_desaturacion_fuerza: float = Form(0.35),
	preparar_corregir_gamma: bool = Form(False),
	preparar_gamma_valor: float = Form(0.6),
	preparar_clahe_contraste: bool = Form(False),
	preparar_saturacion: float = Form(1.0),
	preparar_nitidez: float = Form(1.0),
	preparar_binarizar_otsu: bool = Form(False),
	preparar_modo_simple_escuela: Optional[bool] = Form(None),
):
	start = time.time()
	tmp_path = None
	img = None
	preparar_experimental_applied: list[str] = []
	school_comparator_applied = False
	school_preset_header = "off"
	school_enhance_header = "off"
	try:
		validate_file(file)
		modo_norm = modo.strip().lower()
		if modo_norm not in ("auto", "legacy"):
			raise HTTPException(
				status_code=400,
				detail="modo debe ser 'auto' (único soportado para procesamiento) o 'legacy' (rechazado; use auto).",
			)
		_prepare_reject_legacy_params(
			modo_norm,
			corregir_perspectiva,
			corregir_inclinacion,
			binarizar,
			fuerza_mejora,
		)
		effective_read_dim = OCR_PREPARE_READ_MAX_DIM
		effective_jpeg_quality = OCR_PREPARE_JPEG_QUALITY
		if OCR_PREPARE_ALLOW_REQUEST_TUNING:
			if calidad_jpeg is not None:
				if calidad_jpeg < 1 or calidad_jpeg > 100:
					raise HTTPException(
						status_code=400,
						detail=f"calidad_jpeg debe estar entre 1 y 100 (recibido {calidad_jpeg}).",
					)
				effective_jpeg_quality = calidad_jpeg
			if lado_max_lectura is not None:
				if (
					lado_max_lectura < OCR_PREPARE_READ_MIN_DIM
					or lado_max_lectura > OCR_PREPARE_READ_MAX_DIM_CAP
				):
					raise HTTPException(
						status_code=400,
						detail=(
							f"lado_max_lectura debe estar entre {OCR_PREPARE_READ_MIN_DIM} y "
							f"{OCR_PREPARE_READ_MAX_DIM_CAP} (recibido {lado_max_lectura})."
						),
					)
				effective_read_dim = lado_max_lectura
		elif calidad_jpeg is not None or lado_max_lectura is not None:
			logger.info(
				"/ocr/prepare campos calidad_jpeg/lado_max_lectura ignorados "
				"(OCR_PREPARE_ALLOW_REQUEST_TUNING=false)"
			)

		img, _ = await read_image(
			file,
			compress=False,
			max_size_mb=1.0,
			max_dimension=effective_read_dim,
		)
		pih, piw = img.shape[:2]
		logger.info(
			"/ocr/prepare entrada %dx%d (compress=False, lado_máx_efectivo=%d)",
			piw,
			pih,
			effective_read_dim,
		)

		eff_bb = preparar_balance_blancos
		eff_bi = preparar_balance_intensidad
		eff_ilb = preparar_corregir_iluminacion
		eff_ili = preparar_iluminacion_intensidad
		eff_dsb = preparar_desaturacion_selectiva
		eff_dsf = preparar_desaturacion_fuerza
		eff_gb = preparar_corregir_gamma
		eff_gv = preparar_gamma_valor
		eff_cla = preparar_clahe_contraste
		eff_sat = preparar_saturacion
		eff_nit = preparar_nitidez
		eff_otsu = preparar_binarizar_otsu

		neutral_preparar = is_server_default_prepare_bundle(
			preparar_balance_blancos,
			preparar_balance_intensidad,
			preparar_corregir_iluminacion,
			preparar_iluminacion_intensidad,
			preparar_desaturacion_selectiva,
			preparar_desaturacion_fuerza,
			preparar_corregir_gamma,
			preparar_gamma_valor,
			preparar_clahe_contraste,
			preparar_saturacion,
			preparar_nitidez,
			preparar_binarizar_otsu,
		)
		# None u omitido: auto escuela si multipart neutro. False explícito: no comparador.
		wants_school_comparator = preparar_modo_simple_escuela is not False
		if neutral_preparar and wants_school_comparator:
			school_key = classify_school_lighting(img)
			row = SCHOOL_PREPARE_PRESETS[school_key]
			eff_bb = row.preparar_balance_blancos
			eff_bi = row.preparar_balance_intensidad
			eff_ilb = row.preparar_corregir_iluminacion
			eff_ili = row.preparar_iluminacion_intensidad
			eff_dsb = row.preparar_desaturacion_selectiva
			eff_dsf = row.preparar_desaturacion_fuerza
			eff_gb = row.preparar_corregir_gamma
			eff_gv = row.preparar_gamma_valor
			eff_cla = row.preparar_clahe_contraste
			eff_sat = row.preparar_saturacion
			eff_nit = row.preparar_nitidez
			eff_otsu = row.preparar_binarizar_otsu
			school_comparator_applied = True
			school_preset_header = school_key
			school_enhance_header = (
				"image_enhancer"
				if OCR_PREPARE_ENABLE_AUTO_ENHANCE
				else "skipped_no_auto_enhance_env"
			)
			logger.info(
				"/ocr/prepare school_auto preset=%s enhance_header=%s (modo_simple_escuela=%s)",
				school_key,
				school_enhance_header,
				repr(preparar_modo_simple_escuela),
			)
		elif preparar_modo_simple_escuela is True and not neutral_preparar:
			logger.info(
				"/ocr/prepare preparar_modo_simple_escuela=true pero preparar_* no es paquete "
				"neutro; comparador escuela desactivado"
			)

		_validate_preparar_experimental_multipart(
			eff_nit,
			eff_sat,
			eff_gv,
			eff_bb,
			eff_bi,
			eff_ilb,
			eff_ili,
			eff_dsb,
			eff_dsf,
		)

		img, preparar_experimental_applied = apply_prepare_experimental_stack(
			img,
			preparar_balance_blancos=eff_bb,
			preparar_balance_intensidad=eff_bi,
			preparar_corregir_iluminacion=eff_ilb,
			preparar_iluminacion_intensidad=eff_ili,
			preparar_desaturacion_selectiva=eff_dsb,
			preparar_desaturacion_fuerza=eff_dsf,
			preparar_corregir_gamma=eff_gb,
			preparar_clahe_contraste=eff_cla,
			preparar_saturacion=eff_sat,
			preparar_nitidez=eff_nit,
			preparar_binarizar_otsu=eff_otsu,
			gamma_value=float(eff_gv),
		)
		if preparar_experimental_applied:
			logger.info(
				"/ocr/prepare stage=experimental steps=%s",
				",".join(preparar_experimental_applied),
			)

		want_hsv = _want_hsv_saturation(aplicar_saturacion_hsv)
		if len(img.shape) == 3 and img.shape[2] == 3 and want_hsv:
			wm = compute_white_distance_metrics(img, with_hsv_mult=True)
			s_prep = 1.0 + (float(wm["s_mult"]) - 1.0) * _PREPARE_HSV_SATURATION_DAMPEN
			img = apply_hs_saturation_scale_rgb(img, s_prep)

		clahe_applied = False
		if (
			OCR_PREPARE_SOFT_CLAHE
			and len(img.shape) == 3
			and img.shape[2] == 3
		):
			img = apply_clahe_prepare(img)
			clahe_applied = True
			logger.info("/ocr/prepare CLAHE suave aplicado (OCR_PREPARE_SOFT_CLAHE=true)")

		enhance_status = "off"
		enhance_engine_used = "none"
		enhance_preset_id: str | None = None
		prepare_luma: PrepareLumaClassification | None = None
		force_school_enhance = bool(
			school_comparator_applied and OCR_PREPARE_ENABLE_AUTO_ENHANCE
		)
		should_enhance = bool(OCR_PREPARE_ENABLE_AUTO_ENHANCE) and (
			bool(auto_enhance) or force_school_enhance
		)
		if should_enhance:
			if school_comparator_applied:
				engine = "image_enhancer"
			else:
				engine = (enhance_engine or OCR_PREPARE_ENHANCE_ENGINE_DEFAULT).strip().lower()
			if engine not in ("opencv", "image_enhancer"):
				engine = OCR_PREPARE_ENHANCE_ENGINE_DEFAULT
			original_img = img.copy()
			prepare_luma = classify_prepare_luma(img)
			if engine == "image_enhancer":
				if OCR_PREPARE_IMAGE_ENHANCER_LUMA_PRESETS:
					ie_params, ie_preset_id = image_enhancer_params_for_bucket(prepare_luma.bucket)
				else:
					ie_params = dict(IMAGE_ENHANCER_PARAMS_LEGACY)
					ie_preset_id = "ie_legacy"
				logger.info(
					"/ocr/prepare stage=image_enhancer_luma mean_gray=%.2f contrast_std=%.2f bucket=%s preset=%s",
					prepare_luma.mean_gray,
					prepare_luma.contrast_std,
					prepare_luma.bucket,
					ie_preset_id,
				)
				enhanced, reason = enhance_photometric_image_enhancer(
					img,
					timeout_seconds=OCR_PREPARE_ENHANCE_TIMEOUT_SECONDS,
					params=dict(ie_params),
				)
				enhance_engine_used = "image_enhancer"
				enhance_preset_id = ie_preset_id
				if enhanced is None:
					img = original_img
					enhance_status = "fallback_original"
					logger.warning(
						"/ocr/prepare image_enhancer fallback bucket=%s preset=%s reason=%s",
						prepare_luma.bucket,
						ie_preset_id,
						reason,
					)
				else:
					img = enhanced
					enhance_status = "image_enhancer"
			else:
				enhance_engine_used = "opencv"
				enhance_preset_id = opencv_enhance_preset_id(prepare_luma.bucket)
				try:
					img = enhance_photometric_opencv(img, prepare_luma.bucket)
					enhance_status = "opencv"
				except Exception as exc:
					img = original_img
					enhance_status = "fallback_original"
					enhance_preset_id = f"{enhance_preset_id}_failed"
					logger.warning(
						"/ocr/prepare opencv enhance fallback bucket=%s error=%s",
						prepare_luma.bucket,
						exc,
					)

		img_final = img if len(img.shape) == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

		fd, tmp_path = tempfile.mkstemp(suffix=".jpg")
		os.close(fd)
		cv2.imwrite(
			tmp_path,
			cv2.cvtColor(img_final, cv2.COLOR_RGB2BGR),
			[cv2.IMWRITE_JPEG_QUALITY, effective_jpeg_quality],
		)

		safe_stem = Path(file.filename or "image").stem
		out_name = f"prepared_{safe_stem}.jpg"

		background_tasks.add_task(
			lambda p=tmp_path: os.unlink(p) if os.path.exists(p) else None
		)

		headers: dict[str, str] = {
			"X-OCR-Prepare-Mode": "auto",
			"X-OCR-Prepare-Preset": "preservacion",
			"X-OCR-Prepare-JPEG-Quality": str(effective_jpeg_quality),
			"X-OCR-Prepare-Read-Max-Dim": str(effective_read_dim),
			"X-OCR-Prepare-HSV": "on" if want_hsv else "off",
			"X-OCR-Prepare-CLAHE": "on" if clahe_applied else "off",
			"X-OCR-Prepare-Enhance": enhance_status,
			"X-OCR-Prepare-Enhance-Engine": enhance_engine_used,
			"X-OCR-Prepare-Experimental": (
				"off" if not preparar_experimental_applied else ",".join(preparar_experimental_applied)
			),
			"X-OCR-Prepare-School-Mode": "on" if school_comparator_applied else "off",
			"X-OCR-Prepare-School-Preset": school_preset_header,
			"X-OCR-Prepare-School-Enhance": school_enhance_header,
		}
		if OCR_PREPARE_DIAGNOSTIC_HEADERS and prepare_luma is not None:
			headers["X-OCR-Prepare-Luma-Mean"] = f"{prepare_luma.mean_gray:.2f}"
			headers["X-OCR-Prepare-Luma-Contrast-Stdev"] = f"{prepare_luma.contrast_std:.2f}"
			headers["X-OCR-Prepare-Enhance-Bucket"] = prepare_luma.bucket
			if enhance_preset_id is not None:
				headers["X-OCR-Prepare-Enhance-Preset"] = enhance_preset_id

		logger.info(
			"/ocr/prepare OK en %.2fs (preservacion%s)",
			time.time() - start,
			", clahe" if clahe_applied else "",
		)

		return FileResponse(
			path=tmp_path,
			media_type="image/jpeg",
			filename=out_name,
			headers=headers,
		)
	except HTTPException:
		if tmp_path and os.path.exists(tmp_path):
			os.unlink(tmp_path)
		raise
	except Exception as e:
		if tmp_path and os.path.exists(tmp_path):
			os.unlink(tmp_path)
		logger.exception("Error en /ocr/prepare")
		raise HTTPException(status_code=500, detail=str(e)) from e
	finally:
		if img is not None:
			del img
		gc.collect()


if __name__ == "__main__":
	port = int(os.environ.get("PORT", "10000"))
	uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
