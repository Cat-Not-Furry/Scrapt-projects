# preprocessing/quality.py
"""Métricas de calidad y distancia al blanco para prepare / preprocess_light."""

import cv2
import numpy as np

_MEAN_NEAR_WHITE = 248.0
# AIDA: refuerzo de pipeline acotado (documentos casi blanco + texto negro no deben “explotar” CLAHE/unsharp).
_MAX_RELATIVE_GAIN = 1.04
_BOOST_PIPELINE_CAP = _MAX_RELATIVE_GAIN
# Solo si el cliente pide HSV (`with_hsv_mult=True`): incremento suave de saturación en canal S.
_S_HSV_NEAR_MIN = 1.002
_S_HSV_NEAR_MAX = 1.018


def analyze_image_quality(image: np.ndarray) -> dict:
	"""Retorna métricas y overall_score en [0, 1] (1 = excelente)."""
	if len(image.shape) == 3:
		gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
	else:
		gray = image

	brightness = float(np.mean(gray))
	contrast = float(np.std(gray))
	laplacian_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
	white_ratio = float(np.sum(gray > 250) / gray.size * 100.0)

	brightness_score = min(1.0, brightness / 200.0)
	contrast_score = min(1.0, contrast / 60.0)
	sharpness_score = min(1.0, laplacian_var / 300.0)
	white_penalty = min(1.0, white_ratio / 10.0)

	overall = (
		0.35 * brightness_score
		+ 0.25 * contrast_score
		+ 0.25 * sharpness_score
		- 0.15 * white_penalty
	)
	overall = max(0.0, min(1.0, overall))

	return {
		"brightness": brightness,
		"contrast": contrast,
		"laplacian_var": laplacian_var,
		"white_ratio": white_ratio,
		"overall_score": overall,
	}


def compute_white_distance_metrics(
	image: np.ndarray,
	with_hsv_mult: bool = False,
) -> dict:
	"""
	boost_pipeline: siempre suave (AIDA). s_mult para HSV: 1.0 salvo with_hsv_mult=True (form/env).
	"""
	if len(image.shape) == 3:
		gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
	else:
		gray = image

	mean_gray = float(np.mean(gray))
	d = max(0.0, 255.0 - mean_gray)
	near_white = mean_gray >= _MEAN_NEAR_WHITE
	s_mult = 1.0

	if near_white:
		boost_pipeline = 1.0 + min(0.015, (255.0 - mean_gray) / 400.0)
	else:
		steps = int(d // 35.0)
		boost_pipeline = float(min(_BOOST_PIPELINE_CAP, 1.0 + 0.004 * max(0, steps)))

	boost_pipeline = float(min(_BOOST_PIPELINE_CAP, max(1.0, boost_pipeline)))

	if with_hsv_mult:
		if near_white:
			if mean_gray >= 255.0 - 1e-6:
				s_mult = _S_HSV_NEAR_MIN
			else:
				span = max(1e-6, 255.0 - _MEAN_NEAR_WHITE)
				t = (mean_gray - _MEAN_NEAR_WHITE) / span
				s_mult = _S_HSV_NEAR_MAX - t * (_S_HSV_NEAR_MAX - _S_HSV_NEAR_MIN)
			s_mult = float(min(_S_HSV_NEAR_MAX, max(_S_HSV_NEAR_MIN, s_mult)))
		else:
			steps_h = int(d // 30.0)
			s_mult = float(
				min(_BOOST_PIPELINE_CAP, 1.0 + 0.01 * max(0, steps_h))
			)

	return {
		"mean_gray": mean_gray,
		"d": d,
		"near_white": near_white,
		"boost_pipeline": boost_pipeline,
		"s_mult": s_mult,
	}
