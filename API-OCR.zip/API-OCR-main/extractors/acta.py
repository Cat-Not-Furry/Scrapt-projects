# extractors/acta.py
import re
from typing import Any, Dict, List

from extractors.base import BaseExtractor
from extractors.coords_helpers import find_line_anchor, line_below_anchor
from extractors.name_helpers import pick_allcaps_name, pick_title_name

FECHA_PATTERN = re.compile(
	r"\b(\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\d{4}[-/]\d{1,2}[-/]\d{1,2})\b"
)
FOLIO_LABEL = re.compile(
	r"\bFOLIO\s*:?\s*([A-Z0-9]+(?:[-/][A-Z0-9]+)*)",
	re.I,
)
NAME_PATTERN = re.compile(
	r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)+"
)

_ANCHOR_PERSONA = re.compile(
	r"Datos\s+de\s+la\s+Persona\s+Registrada|Persona\s+Registrada|"
	r"Datos\s+de\s+la\s+Persona|REGISTRADA|REGISTRO\s+CIVIL|ACTA\s+DE\s+NACIMIENTO",
	re.I,
)
_ANCHOR_FILIACION = re.compile(r"Filiaci[oó]n|Datos\s+de\s+la\s+Filiaci", re.I)
def _normalize_newlines(text: str) -> str:
	return text.replace("\r\n", "\n").replace("\r", "\n")


def _lines(text: str) -> List[str]:
	return [ln.strip() for ln in _normalize_newlines(text).split("\n")]


def _bloque_persona(text: str) -> str:
	n = _normalize_newlines(text)
	lines_list = _lines(n)
	start = -1
	for i, ln in enumerate(lines_list):
		if _ANCHOR_PERSONA.search(ln):
			start = i
			break
	if start < 0:
		for i, ln in enumerate(lines_list):
			if re.search(
				r"Primer\s+Apellido|Nombre\(s\)|Apellido\s+Paterno|Nombre\s+de\s+la\s+Persona",
				ln,
				re.I,
			):
				start = max(0, i - 2)
				break
	if start < 0:
		return n
	end = len(lines_list)
	for j in range(start + 1, len(lines_list)):
		if _ANCHOR_FILIACION.search(lines_list[j]):
			end = j
			break
	return "\n".join(lines_list[start:end])


def _folio_acta(text: str) -> tuple[str | None, float]:
	m = FOLIO_LABEL.search(text)
	if m:
		return m.group(1).strip(), 0.88
	n = _normalize_newlines(text)
	m2 = re.search(
		r"\bFOLIO\b\s*\n\s*([A-Z0-9]{4,}(?:[-/][A-Z0-9]+)*)",
		n,
		re.I,
	)
	if m2:
		return m2.group(1).strip(), 0.85
	m3 = re.search(
		r"\bF[\sO]*L[\sI]*O[\s]*\s*:?\s*([A-Z0-9]{4,}(?:[-/][A-Z0-9]+)*)",
		n,
		re.I,
	)
	if m3:
		return m3.group(1).strip(), 0.78
	m4 = re.search(
		r"(?:folio|no\.?)\s*:?\s*([A-Z0-9]{3,}(?:[-/][A-Z0-9]+)*)",
		n,
		re.I,
	)
	if m4:
		return m4.group(1).strip(), 0.72
	return None, 0.0


def _fecha_nacimiento_bloque(bloque: str) -> tuple[str | None, float]:
	lines_list = _lines(bloque)
	for i, ln in enumerate(lines_list):
		if re.search(r"Fecha\s+de\s+Nacimiento|Nacimiento", ln, re.I):
			window = "\n".join(lines_list[i : min(i + 6, len(lines_list))])
			for m in FECHA_PATTERN.finditer(window):
				return m.group(1), 0.9
	for m in FECHA_PATTERN.finditer(bloque):
		return m.group(1), 0.72
	return None, 0.0


_CURP_INLINE = re.compile(
	r"\b[A-Z]{4}\d{6}[HM][A-Z]{5}[0-9A-Z][0-9]\b",
	re.I,
)


def _nombre_persona_registrada(bloque: str) -> tuple[str | None, float]:
	lines_list = _lines(bloque)
	chunks: list[str] = []
	for ln in lines_list:
		if re.search(
			r"Nombre|Apellido|Fecha|Sexo|CURP|Filiaci|Registrad|Domicilio|Calle|Col\.|Municipio",
			ln,
			re.I,
		):
			continue
		if _CURP_INLINE.search(ln):
			continue
		if len(ln) > 3 and re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]", ln):
			chunks.append(ln)
	if len(chunks) >= 2:
		return " ".join(chunks[:4]), 0.78
	bl = "\n".join(lines_list)
	nm, c = pick_title_name(bl)
	if nm:
		return nm, c
	return pick_allcaps_name(bl, 0.55)


def _padre_madre(text: str) -> tuple[str | None, str | None, float, float]:
	n = _normalize_newlines(text)
	lines_list = _lines(n)
	fi = -1
	for i, ln in enumerate(lines_list):
		if _ANCHOR_FILIACION.search(ln):
			fi = i
			break
	if fi < 0:
		p = re.search(
			r"padre\s*:?\s*(.+?)(?=\n|madre\s*:?)",
			n,
			re.I | re.DOTALL,
		)
		m = re.search(
			r"madre\s*:?\s*(.+?)(?=\n|padre\s*:?|folio)",
			n,
			re.I | re.DOTALL,
		)
		pr = p.group(1).strip() if p else None
		mr = m.group(1).strip() if m else None
		return pr, mr, 0.72 if pr else 0.0, 0.72 if mr else 0.0

	segment = lines_list[fi + 1 : min(fi + 40, len(lines_list))]
	padre = madre = None
	for i, ln in enumerate(segment):
		if re.search(r"padre|nombre\s+del\s+padre", ln, re.I):
			if i + 1 < len(segment):
				padre = segment[i + 1].strip()
			break
	for i, ln in enumerate(segment):
		if re.search(r"madre|nombre\s+de\s+la\s+madre", ln, re.I):
			if i + 1 < len(segment):
				madre = segment[i + 1].strip()
			break
	pc = 0.78 if padre and len(padre) > 2 else 0.0
	mc = 0.78 if madre and len(madre) > 2 else 0.0
	return padre, madre, pc, mc


def _refinar_nombre_persona(valor: str | None) -> str | None:
	if not valor:
		return None
	valor = valor.strip()
	if len(valor) < 3:
		return valor
	t, _ = pick_title_name(valor)
	if t:
		return t
	a, _ = pick_allcaps_name(valor, 0.55)
	if a:
		return a
	return valor


class ActaExtractor(BaseExtractor):
	def empty_fields(self) -> Dict[str, Any]:
		return {
			"nombre": self._field_null(),
			"fecha_nacimiento": self._field_null(),
			"folio": self._field_null(),
			"padre": self._field_null(),
			"madre": self._field_null(),
		}

	def extract_with_coords(
		self,
		text: str,
		lines: list[dict[str, Any]] | None = None,
		words: list[dict[str, Any]] | None = None,
	) -> Dict[str, Any]:
		_ = words
		if not lines:
			return self.extract(text)
		folio = None
		folio_conf = 0.0
		nombre = None
		nombre_conf = 0.0
		fecha_nacimiento = None
		fecha_conf = 0.0
		padre = None
		madre = None
		padre_conf = 0.0
		madre_conf = 0.0
		folio_anchor = find_line_anchor(lines, [r"\bFOLIO\b"])
		if folio_anchor:
			ln = line_below_anchor(lines, folio_anchor, min_dy=3, max_dy=45)
			if ln:
				m = re.search(r"\b([A-Z0-9]{2,}(?:\s+[A-Z0-9]{2,})?)\b", ln.get("text", ""), re.I)
				if m:
					folio = m.group(1).strip()
					folio_conf = 0.9
		nom_anchor = find_line_anchor(lines, [r"NOMBRE\(S\)", r"NOMBRE"])
		if nom_anchor:
			ln = line_below_anchor(lines, nom_anchor, min_dy=-30, max_dy=20)
			if ln:
				nombre = ln.get("text", "").strip()
				nombre_conf = 0.82
		fecha_anchor = find_line_anchor(lines, [r"FECHA\s+DE\s+NACIMIENTO", r"NACIMIENTO"])
		if fecha_anchor:
			for ln in lines:
				dy = int(fecha_anchor.get("top", 0)) - int(ln.get("top", 0))
				if dy < -8 or dy > 50:
					continue
				m = FECHA_PATTERN.search(ln.get("text", ""))
				if m:
					fecha_nacimiento = m.group(1).replace("-", "/").replace("'", "/").replace(",", "/")
					fecha_conf = 0.9
					break
		fallback = self.extract(text)
		if not nombre:
			nombre = fallback["nombre"]["value"]
			nombre_conf = fallback["nombre"]["confidence"]
		if not fecha_nacimiento:
			fecha_nacimiento = fallback["fecha_nacimiento"]["value"]
			fecha_conf = fallback["fecha_nacimiento"]["confidence"]
		if not folio:
			folio = fallback["folio"]["value"]
			folio_conf = fallback["folio"]["confidence"]
		padre = fallback["padre"]["value"]
		padre_conf = fallback["padre"]["confidence"]
		madre = fallback["madre"]["value"]
		madre_conf = fallback["madre"]["confidence"]
		return {
			"nombre": {"value": nombre, "confidence": nombre_conf},
			"fecha_nacimiento": {"value": fecha_nacimiento, "confidence": fecha_conf},
			"folio": {"value": folio, "confidence": folio_conf},
			"padre": {"value": padre, "confidence": padre_conf},
			"madre": {"value": madre, "confidence": madre_conf},
		}

	def extract(self, text: str) -> Dict[str, Any]:
		n = _normalize_newlines(text)
		bloque = _bloque_persona(n)
		folio, folio_conf = _folio_acta(n)
		fecha_nacimiento, fecha_conf = _fecha_nacimiento_bloque(bloque)

		nombre, nombre_conf = _nombre_persona_registrada(bloque)
		if not nombre:
			nombre_match = NAME_PATTERN.search(bloque)
			if nombre_match:
				nombre = nombre_match.group()
				nombre_conf = 0.7
		if not nombre:
			nombre, nombre_conf = pick_title_name(bloque)
		if not nombre:
			nombre, nombre_conf = pick_allcaps_name(bloque, 0.55)

		padre_raw, madre_raw, pc, mc = _padre_madre(n)
		padre = _refinar_nombre_persona(padre_raw)
		madre = _refinar_nombre_persona(madre_raw)
		padre_conf = pc if padre else 0.0
		madre_conf = mc if madre else 0.0

		return {
			"nombre": {"value": nombre, "confidence": nombre_conf},
			"fecha_nacimiento": {"value": fecha_nacimiento, "confidence": fecha_conf},
			"folio": {"value": folio, "confidence": folio_conf},
			"padre": {"value": padre, "confidence": padre_conf},
			"madre": {"value": madre, "confidence": madre_conf},
		}
