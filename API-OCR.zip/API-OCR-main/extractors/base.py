# extractors/base.py
from typing import Dict, Any


class BaseExtractor:
	"""Clase base para extractores de documentos. Opera sobre texto plano."""

	def _field_null(self) -> Dict:
		return {"value": None, "confidence": 0}

	def _field_value(self, value: str, confidence: float) -> Dict:
		return {"value": value, "confidence": confidence}

	def extract(self, text: str) -> Dict[str, Any]:
		"""Extrae campos del texto plano y devuelve un diccionario con valores y confianza."""
		raise NotImplementedError

	def extract_with_coords(
		self,
		text: str,
		lines: list[dict[str, Any]] | None = None,
		words: list[dict[str, Any]] | None = None,
	) -> Dict[str, Any]:
		"""
		Fallback por defecto: usa extracción en texto plano.
		"""
		_ = lines
		_ = words
		return self.extract(text)

	def empty_fields(self) -> Dict[str, Any]:
		"""
		Estructura nula por extractor para respuesta silenciosa (200 con OCR fallido).
		"""
		raise NotImplementedError
