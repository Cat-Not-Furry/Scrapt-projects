# extractors/ine.py
import re
from typing import Any, Dict, List

from extractors.base import BaseExtractor
from extractors.coords_helpers import find_line_anchor
from extractors.name_helpers import pick_allcaps_name, pick_title_name

CLAVE_ELECTOR_PATTERN = re.compile(r"\b([A-Z]{6}[0-9]{8}[A-Z][0-9]{3})\b")
VIGENCIA_PATTERN = re.compile(
	r"\b(?:vigencia|vence|validez)\s*:?\s*(\d{2}[-/]\d{2}[-/]\d{2,4})\b",
	re.I,
)
VIGENCIA_ANIOS_PATTERN = re.compile(r"\b(\d{4})\s*[-–]\s*(\d{4})\b")
VIGENCIA_HASTA_PATTERN = re.compile(
	r"\bvigencia\s+hasta\s*:?\s*(\d{4})\b",
	re.I,
)
NAME_PATTERN = re.compile(
	r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)+"
)

_ANCHOR_CREDENCIAL = re.compile(
	r"CREDENCIAL\s+PARA\s+VOTAR|CREDENCIAL\s+[\w\s]*VOTAR|PARA\s+VOTAR|"
	r"INSTITUTO\s+[\w\s]*ELECTORAL|IFE\b|\bINE\b",
	re.I,
)
_STOP_NOMBRE = re.compile(
	r"^(DOMICILIO|CALLE|COL\.?|COLONIA|SECCI[ÓO]N|MUNICIPIO|ESTADO|C\.?\s*P|C\.P\.|"
	r"CLAVE\s+ELECTOR|CLAVE\s*:|ELECTOR|INSTITUTO|IFE|INE|VIGENCIA|EMISI[ÓO]N|FECHA|SEXO|NACIONALIDAD)\b",
	re.I,
)
_CP_NEAR = re.compile(
	r"(?:C\.?\s*P\.?|C\.P\.)\s*:?\s*(\d{5})\b",
	re.I,
)
_CP_INLINE = re.compile(r"\b(\d{5})\b")


def _normalize_newlines(text: str) -> str:
	return text.replace("\r\n", "\n").replace("\r", "\n")


def _lines(text: str) -> List[str]:
	return [ln.strip() for ln in _normalize_newlines(text).split("\n")]


def _nombre_credencial_anchor(lines_list: List[str]) -> tuple[str | None, float]:
	start = -1
	for i, ln in enumerate(lines_list):
		if _ANCHOR_CREDENCIAL.search(ln):
			start = i + 1
			break
	if start < 0:
		return None, 0.0
	parts: list[str] = []
	for j in range(start, min(start + 14, len(lines_list))):
		ln = lines_list[j]
		if not ln:
			continue
		if _STOP_NOMBRE.match(ln):
			break
		if re.search(r"\d{8,}", ln):
			continue
		upperish = sum(1 for c in ln if c.isupper())
		if len(ln) >= 4 and upperish >= len(ln) * 0.35:
			parts.append(ln)
	if not parts:
		return None, 0.0
	return " ".join(parts), 0.82


def _clave_compact_alnum(text: str) -> tuple[str | None, float]:
	"""Clave sin espacios (OCR partido en líneas)."""
	compact = re.sub(r"\s+", "", text.upper())
	m = re.search(r"([A-Z]{6}\d{8}[A-Z]\d{3})", compact)
	if m:
		return m.group(1).upper(), 0.86
	return None, 0.0


def _clave_en_ventana(text: str) -> tuple[str | None, float]:
	idx = text.upper().find("DOMICILIO")
	segment = text[idx:] if idx >= 0 else text
	m = CLAVE_ELECTOR_PATTERN.search(segment[:5000])
	if m:
		return m.group(1).upper(), 0.95
	m2 = CLAVE_ELECTOR_PATTERN.search(text)
	if m2:
		return m2.group(1).upper(), 0.88
	c, cc = _clave_compact_alnum(text)
	if c:
		return c, cc
	return None, 0.0


def _nombre_tras_label_nombre(lines_list: List[str]) -> tuple[str | None, float]:
	for i, ln in enumerate(lines_list):
		if not re.search(r"\bNOMBRE\b", ln, re.I):
			continue
		if re.search(r"ELECTOR|PADRE|MADRE|TUTOR", ln, re.I):
			continue
		parts: list[str] = []
		for j in range(i + 1, min(i + 12, len(lines_list))):
			ln2 = lines_list[j]
			if not ln2.strip():
				if parts:
					break
				continue
			if _STOP_NOMBRE.match(ln2):
				break
			if re.match(r"^\d{5,}$", ln2.replace(" ", "")):
				break
			letters = sum(1 for c in ln2 if c.isalpha())
			if letters >= 3 and len(ln2) >= 3:
				parts.append(ln2.strip())
			elif parts:
				break
		if len(parts) >= 1:
			return " ".join(parts[:4]), 0.8
	return None, 0.0


def _codigo_postal(text: str) -> tuple[str | None, float]:
	m = _CP_NEAR.search(text)
	if m:
		return m.group(1), 0.9
	for ln in _lines(text):
		if re.search(r"COL|COLONIA|DOMICILIO|MUNICIPIO|CALLE", ln, re.I):
			m2 = _CP_INLINE.search(ln)
			if m2:
				return m2.group(1), 0.78
	return None, 0.0


def _mejor_vigencia(text: str) -> tuple[str | None, float]:
	n = _normalize_newlines(text)
	lines_list = _lines(n)
	for i, ln in enumerate(lines_list):
		if re.search(r"\bVIGENCIA\b", ln, re.I):
			window = "\n".join(lines_list[i : min(i + 5, len(lines_list))])
			m = VIGENCIA_ANIOS_PATTERN.search(window)
			if m:
				return f"{m.group(1)}-{m.group(2)}", 0.9
			m_old = VIGENCIA_PATTERN.search(window)
			if m_old:
				return m_old.group(1), 0.85
			break
	m_anios = VIGENCIA_ANIOS_PATTERN.search(n)
	if m_anios:
		return f"{m_anios.group(1)}-{m_anios.group(2)}", 0.88
	m_hasta = VIGENCIA_HASTA_PATTERN.search(n)
	if m_hasta:
		return m_hasta.group(1), 0.85
	m_old = VIGENCIA_PATTERN.search(n)
	if m_old:
		return m_old.group(1), 0.85
	return None, 0.0


class INEExtractor(BaseExtractor):
	def empty_fields(self) -> Dict[str, Any]:
		return {
			"nombre_tutor": self._field_null(),
			"clave_elector": self._field_null(),
			"codigo_postal": self._field_null(),
			"ocr_id": self._field_null(),
			"vigencia": self._field_null(),
		}

	def extract_with_coords(
		self,
		text: str,
		lines: list[dict[str, Any]] | None = None,
		words: list[dict[str, Any]] | None = None,
	) -> Dict[str, Any]:
		_ = words
		if not lines:
			return self.extract(text)
		nombre_tutor = None
		nombre_conf = 0.0
		clave_elector = None
		clave_conf = 0.0
		codigo_postal = None
		cp_conf = 0.0
		ocr_id = None
		ocr_conf = 0.0
		vigencia = None
		vigencia_conf = 0.0
		cred_anchor = find_line_anchor(lines, [r"CREDENCIAL\s+PARA\s+VOTAR"])
		if cred_anchor:
			base_top = int(cred_anchor.get("top", 0))
			name_lines = [
				ln for ln in lines
				if int(ln.get("top", 0)) > base_top + 15 and int(ln.get("top", 0)) < base_top + 180
			]
			name_lines.sort(key=lambda x: int(x.get("top", 0)))
			name_parts = []
			for ln in name_lines[:4]:
				t = ln.get("text", "").strip()
				if re.search(r"\b(C|CALLE|COL|CP|FECHA|VIGENCIA)\b", t, re.I):
					break
				if t:
					name_parts.append(t)
			if name_parts:
				nombre_tutor = " ".join(name_parts).strip()
				nombre_conf = 0.78
		for ln in lines:
			t = ln.get("text", "")
			if not codigo_postal:
				cp = re.search(r"\b(\d{5})\b", t)
				if cp and re.search(r"COL|CP|C\.P|SUR|JOYA|CALLE|LTE", t, re.I):
					codigo_postal = cp.group(1)
					cp_conf = 0.82
			if not clave_elector:
				m = CLAVE_ELECTOR_PATTERN.search(t.replace(" ", "").upper())
				if m:
					clave_elector = m.group(1).upper()
					clave_conf = 0.9
			if not vigencia:
				vm = re.search(r"\b(20\d{2})\b", t)
				if vm and re.search(r"VIG|VG|VENC", t, re.I):
					vigencia = vm.group(1)
					vigencia_conf = 0.84
		fallback = self.extract(text)
		if not nombre_tutor:
			nombre_tutor = fallback["nombre_tutor"]["value"]
			nombre_conf = fallback["nombre_tutor"]["confidence"]
		if not clave_elector:
			clave_elector = fallback["clave_elector"]["value"]
			clave_conf = fallback["clave_elector"]["confidence"]
		if not codigo_postal:
			codigo_postal = fallback["codigo_postal"]["value"]
			cp_conf = fallback["codigo_postal"]["confidence"]
		if not vigencia:
			vigencia = fallback["vigencia"]["value"]
			vigencia_conf = fallback["vigencia"]["confidence"]
		if not ocr_id and codigo_postal:
			ocr_id = codigo_postal
			ocr_conf = cp_conf * 0.95
		return {
			"nombre_tutor": {"value": nombre_tutor, "confidence": nombre_conf},
			"clave_elector": {"value": clave_elector, "confidence": clave_conf},
			"codigo_postal": {"value": codigo_postal, "confidence": cp_conf},
			"ocr_id": {"value": ocr_id, "confidence": ocr_conf},
			"vigencia": {"value": vigencia, "confidence": vigencia_conf},
		}

	def extract(self, text: str) -> Dict[str, Any]:
		n = _normalize_newlines(text)
		lines_n = _lines(n)
		clave_elector, clave_conf = _clave_en_ventana(n)
		vigencia, vigencia_conf = _mejor_vigencia(n)
		codigo_postal, cp_conf = _codigo_postal(n)

		nombre_tutor, nombre_conf = _nombre_credencial_anchor(lines_n)
		if not nombre_tutor:
			nombre_tutor, nombre_conf = _nombre_tras_label_nombre(lines_n)
		if not nombre_tutor:
			tutor_match = re.search(
				r"(?:tutor|titular)\s*:?\s*(.+?)(?:\s*(?:clave|folio)|\s*$)",
				n,
				re.I,
			)
			if tutor_match:
				nombre_tutor = tutor_match.group(1).strip()
				nombre_conf = 0.75
		if not nombre_tutor:
			nombre_label = re.search(
				r"\bnombre\s*:?\s*(.+?)(?:\s{2,}|\n|$)",
				n,
				re.I,
			)
			if nombre_label:
				raw = nombre_label.group(1).strip()
				if len(raw) > 3 and not re.match(
					r"^(clave|elector|vigencia|credencial)\b",
					raw,
					re.I,
				):
					nombre_tutor = raw
					nombre_conf = 0.72
		if not nombre_tutor:
			if not any(
				k in n.upper() for k in ["CLAVE", "FOLIO", "VIGENCIA", "ELECTOR"]
			):
				name_match = NAME_PATTERN.search(n)
				if name_match:
					nombre_tutor = name_match.group()
					nombre_conf = 0.6
		if not nombre_tutor:
			nm, c = pick_title_name(n)
			if nm:
				nombre_tutor, nombre_conf = nm, max(nombre_conf, c)
			else:
				nm, c = pick_allcaps_name(n, 0.55)
				if nm:
					nombre_tutor, nombre_conf = nm, max(nombre_conf, c)

		ocr_id = None
		ocr_conf = 0.0
		ocr_match = re.search(r"ocr\s*(?:id|#)?\s*:?\s*(\d+)", n, re.I)
		if ocr_match:
			ocr_id = ocr_match.group(1)
			ocr_conf = 0.8
		elif codigo_postal:
			ocr_id = codigo_postal
			ocr_conf = cp_conf * 0.95

		return {
			"nombre_tutor": {"value": nombre_tutor, "confidence": nombre_conf},
			"clave_elector": {"value": clave_elector, "confidence": clave_conf},
			"codigo_postal": {"value": codigo_postal, "confidence": cp_conf},
			"ocr_id": {"value": ocr_id, "confidence": ocr_conf},
			"vigencia": {"value": vigencia, "confidence": vigencia_conf},
		}
