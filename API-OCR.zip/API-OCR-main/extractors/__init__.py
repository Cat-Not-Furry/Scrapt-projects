# extractors/__init__.py
from extractors.base import BaseExtractor
from extractors.curp import CURPExtractor
from extractors.acta import ActaExtractor
from extractors.ine import INEExtractor
from extractors.comprobante import ComprobanteExtractor
from extractors.certificado_medico import CertificadoMedicoExtractor
from extractors.key_points import extract_key_points

__all__ = [
	"BaseExtractor",
	"CURPExtractor",
	"ActaExtractor",
	"INEExtractor",
	"ComprobanteExtractor",
	"CertificadoMedicoExtractor",
	"extract_key_points",
]
