# extractors/key_points.py
"""Extracción genérica de puntos clave (fechas, nombres, tipo de documento)."""
import re
from typing import Dict, Any

DATE_PATTERNS = [
	r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}",  # dd/mm/yyyy
	r"\d{1,2}\s+de\s+[a-zA-Záéíóúñ]+\s+de\s+\d{4}",  # dd de mes de aaaa
	r"\d{4}-\d{1,2}-\d{1,2}",  # yyyy-mm-dd
]

NAME_PATTERN = re.compile(
	r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)+"
)


def extract_key_points(text: str) -> Dict[str, Any]:
	"""
	Extrae fechas, posibles nombres y tipo de documento del texto plano.
	"""
	if not text or not text.strip():
		return {"fechas": [], "nombres": [], "tipo_documento": None}

	text_upper = text.upper()
	fechas = []
	for pattern in DATE_PATTERNS:
		matches = re.findall(pattern, text)
		fechas.extend(matches)
	fechas = list(dict.fromkeys(fechas))

	nombres = NAME_PATTERN.findall(text)
	nombres = list(dict.fromkeys(nombres))[:3]

	tipo_documento = None
	if "ACTA DE NACIMIENTO" in text_upper.replace("Í", "I"):
		tipo_documento = "acta_nacimiento"
	elif "CURP" in text_upper:
		tipo_documento = "curp"
	elif "INE" in text_upper or "CREDENCIAL" in text_upper or "INSTITUTO NACIONAL ELECTORAL" in text_upper:
		tipo_documento = "ine"
	elif "COMPROBANTE" in text_upper or "DOMICILIO" in text_upper:
		tipo_documento = "comprobante"
	elif "CERTIFICADO" in text_upper and ("MÉDICO" in text_upper or "MEDICO" in text_upper):
		tipo_documento = "certificado_medico"

	return {
		"fechas": fechas,
		"nombres": nombres,
		"tipo_documento": tipo_documento,
	}
