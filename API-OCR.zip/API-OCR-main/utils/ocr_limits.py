# utils/ocr_limits.py
"""Rate limit y utilidades para /ocr/* (memoria por proceso; varias réplicas = límites independientes)."""
import asyncio
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from typing import DefaultDict, List

from fastapi import HTTPException, Request

from config import (
	OCR_MAX_CONCURRENT_REQUESTS,
	OCR_RATE_LIMIT_REQUESTS,
	OCR_RATE_LIMIT_WINDOW_SECONDS,
)

_rate_lock = asyncio.Lock()
_rate_buckets: DefaultDict[str, List[float]] = defaultdict(list)

_ocr_sem: asyncio.Semaphore | None
if OCR_MAX_CONCURRENT_REQUESTS > 0:
	_ocr_sem = asyncio.Semaphore(OCR_MAX_CONCURRENT_REQUESTS)
else:
	_ocr_sem = None


def client_ip_for_rate_limit(request: Request) -> str:
	xff = request.headers.get("x-forwarded-for")
	if xff:
		first = xff.split(",")[0].strip()
		if first:
			return first
	if request.client and request.client.host:
		return request.client.host
	return "unknown"


async def check_ocr_rate_limit(request: Request) -> None:
	if OCR_RATE_LIMIT_REQUESTS <= 0:
		return
	now = time.monotonic()
	window = float(OCR_RATE_LIMIT_WINDOW_SECONDS)
	cutoff = now - window
	ip = client_ip_for_rate_limit(request)
	async with _rate_lock:
		arr = _rate_buckets[ip]
		arr[:] = [t for t in arr if t >= cutoff]
		if len(arr) >= OCR_RATE_LIMIT_REQUESTS:
			oldest = min(arr)
			retry_after = int(oldest + window - now) + 1
			retry_after = max(1, retry_after)
			raise HTTPException(
				status_code=429,
				detail="Demasiadas solicitudes OCR en la ventana configurada. Reintenta más tarde.",
				headers={"Retry-After": str(retry_after)},
			)
		arr.append(now)


@asynccontextmanager
async def ocr_concurrency_slot():
	if _ocr_sem is None:
		yield
		return
	async with _ocr_sem:
		yield


async def ocr_rate_limit_dep(request: Request):
	await check_ocr_rate_limit(request)
	yield


async def ocr_concurrency_dep():
	async with ocr_concurrency_slot():
		yield
