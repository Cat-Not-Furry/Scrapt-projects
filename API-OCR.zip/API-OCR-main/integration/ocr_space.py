"""
Integración principal con OCR.space (overlay + texto plano).
"""
from __future__ import annotations

import logging
import os
import tempfile
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import cv2
import requests

from config import OCR_SPACE_MAX_UPLOAD_BYTES, OCR_SPACE_TIMEOUT

logger = logging.getLogger(__name__)

OCR_SPACE_URL = "https://api.ocr.space/parse/image"
OCR_SPACE_URL = "https://api.ocr.space/parse/image"


@dataclass
class OCRSpaceResult:
	text: str
	lines: List[Dict[str, Any]]
	words: List[Dict[str, Any]]
	ok: bool
	error_stage: Optional[str] = None
	error_detail: Optional[str] = None
	ocr_exit_code: Optional[Any] = None


def _ensure_under_limit(
	image_path: str,
	max_bytes: int = OCR_SPACE_MAX_UPLOAD_BYTES,
) -> Tuple[str, List[str]]:
	to_cleanup: List[str] = []
	try:
		if os.path.getsize(image_path) <= max_bytes:
			return image_path, to_cleanup
	except OSError:
		return image_path, to_cleanup
	img = cv2.imread(image_path, cv2.IMREAD_COLOR)
	if img is None:
		return image_path, to_cleanup
	work = img
	for scale in (1.0, 0.92, 0.84, 0.76, 0.68):
		if scale < 1.0:
			h, w = work.shape[:2]
			work = cv2.resize(work, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA)
		for q in (95, 88, 80, 72, 64, 56, 48, 40):
			fd, tmp = tempfile.mkstemp(suffix=".jpg")
			os.close(fd)
			to_cleanup.append(tmp)
			if not cv2.imwrite(tmp, work, [cv2.IMWRITE_JPEG_QUALITY, q]):
				continue
			try:
				if os.path.getsize(tmp) <= max_bytes:
					return tmp, to_cleanup
			except OSError:
				continue
	return to_cleanup[-1] if to_cleanup else image_path, to_cleanup


def _parse_overlay(parsed_result: Dict[str, Any]) -> Tuple[str, List[Dict[str, Any]], List[Dict[str, Any]]]:
	overlay = parsed_result.get("TextOverlay") or {}
	parsed_text = (parsed_result.get("ParsedText") or "").strip()
	lines_out: List[Dict[str, Any]] = []
	words_out: List[Dict[str, Any]] = []
	lines = overlay.get("Lines") or []
	for idx, ln in enumerate(lines):
		ln_words = ln.get("Words") or []
		ln_words_sorted = sorted(ln_words, key=lambda w: int(w.get("Left", 0)))
		text_parts: List[str] = []
		for w in ln_words_sorted:
			word_text = (w.get("WordText") or "").strip()
			if not word_text:
				continue
			left = int(w.get("Left", 0))
			top = int(w.get("Top", 0))
			width = int(w.get("Width", 0))
			height = int(w.get("Height", 0))
			words_out.append(
				{
					"text": word_text,
					"left": left,
					"top": top,
					"width": width,
					"height": height,
					"line_idx": idx,
				}
			)
			text_parts.append(word_text)
		if text_parts:
			line_text = " ".join(text_parts).strip()
			line_top = min(int(w.get("Top", 0)) for w in ln_words if (w.get("WordText") or "").strip())
			line_left = min(int(w.get("Left", 0)) for w in ln_words if (w.get("WordText") or "").strip())
			lines_out.append(
				{
					"idx": idx,
					"text": line_text,
					"top": line_top,
					"left": line_left,
				}
			)
	lines_out.sort(key=lambda x: (int(x["top"]), int(x["left"])))
	rebuilt = "\n".join(ln["text"] for ln in lines_out).strip()
	if rebuilt and len(rebuilt) >= max(12, int(len(parsed_text) * 0.45)):
		return rebuilt, lines_out, words_out
	return parsed_text, lines_out, words_out


def ocr_space_extract(image_path: str, language: str = "spa") -> OCRSpaceResult:
	api_key = os.getenv("OCR_SPACE_API_KEY")
	if not api_key:
		return OCRSpaceResult(
			text="",
			lines=[],
			words=[],
			ok=False,
			error_stage="ocr_space_call",
			error_detail="OCR_SPACE_API_KEY no configurada",
		)

	upload_path, cleanup = _ensure_under_limit(image_path, OCR_SPACE_MAX_UPLOAD_BYTES)
	payload = {
		"apikey": api_key,
		"language": language,
		"isOverlayRequired": True,
		"detectOrientation": True,
		"OCREngine": 1,
	}
	try:
		with open(upload_path, "rb") as f:
			response = requests.post(
				OCR_SPACE_URL,
				files={"file": f},
				data=payload,
				timeout=OCR_SPACE_TIMEOUT,
			)
		response.raise_for_status()
		data = response.json()
		parsed = data.get("ParsedResults")
		if not parsed:
			return OCRSpaceResult(
				text="",
				lines=[],
				words=[],
				ok=False,
				error_stage="overlay_parse",
				error_detail=f"sin ParsedResults: {data.get('ErrorMessage') or data.get('ErrorDetails') or 'sin detalle'}",
				ocr_exit_code=data.get("OCRExitCode"),
			)
		first = parsed[0]
		if first.get("IsErroredOnProcessing"):
			return OCRSpaceResult(
				text="",
				lines=[],
				words=[],
				ok=False,
				error_stage="overlay_parse",
				error_detail=f"errored_on_processing: {first.get('ErrorMessage') or first.get('ErrorDetails') or 'sin detalle'}",
				ocr_exit_code=data.get("OCRExitCode"),
			)
		texto, lines_out, words_out = _parse_overlay(first)
		if not texto.strip():
			return OCRSpaceResult(
				text="",
				lines=lines_out,
				words=words_out,
				ok=False,
				error_stage="overlay_parse",
				error_detail="texto vacío",
				ocr_exit_code=data.get("OCRExitCode"),
			)
		return OCRSpaceResult(
			text=texto.strip(),
			lines=lines_out,
			words=words_out,
			ok=True,
			ocr_exit_code=data.get("OCRExitCode"),
		)
	except requests.RequestException as e:
		return OCRSpaceResult(
			text="",
			lines=[],
			words=[],
			ok=False,
			error_stage="ocr_space_call",
			error_detail=f"request_exception: {e}",
		)
	except (ValueError, KeyError, TypeError) as e:
		return OCRSpaceResult(
			text="",
			lines=[],
			words=[],
			ok=False,
			error_stage="overlay_parse",
			error_detail=f"parse_exception: {e}",
		)
	finally:
		for p in cleanup:
			if p != image_path:
				try:
					os.unlink(p)
				except OSError:
					pass
